# aggregate

This project is __*actively maintained*__

User documentation is [here](https://opendatakit.org/use/aggregate/)

The Google group for user questions is: [opendatakit@](https://groups.google.com/forum/#!forum/opendatakit)

See [CONFIGURE.txt](https://github.com/opendatakit/aggregate/blob/master/CONFIGURE.txt) for build information
and [README.txt](https://github.com/opendatakit/aggregate/blob/master/README.txt) for upgrade information.

The developer [wiki](https://github.com/opendatakit/opendatakit/wiki) (including release notes) and
[issues tracker](https://github.com/opendatakit/opendatakit/issues) are located under
the [**opendatakit**](https://github.com/opendatakit/opendatakit) project.

The Google group for software engineering questions is: [opendatakit-developers@](https://groups.google.com/forum/#!forum/opendatakit-developers)

-------
License

This software is licensed under the [**Apache 2.0 license**](http://www.apache.org/licenses/LICENSE-2.0)

