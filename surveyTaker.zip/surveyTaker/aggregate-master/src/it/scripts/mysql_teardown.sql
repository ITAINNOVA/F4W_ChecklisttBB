drop database `odk_unit`;
drop user 'odk_unit'@'localhost';
