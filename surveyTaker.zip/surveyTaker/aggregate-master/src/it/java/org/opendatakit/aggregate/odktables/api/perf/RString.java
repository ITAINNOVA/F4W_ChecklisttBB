package org.opendatakit.aggregate.odktables.api.perf;

public class RString {

  public static int deleting_local_file;
  public static int verifying_local_file;
  public static int deleting_file_on_server;
  public static int uploading_local_file;
  public static int getting_table_manifest;
  public static int getting_app_level_manifest;

}
