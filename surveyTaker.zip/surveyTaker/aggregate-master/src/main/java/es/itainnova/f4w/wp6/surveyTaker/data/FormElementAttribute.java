package es.itainnova.f4w.wp6.surveyTaker.data;

public class FormElementAttribute {

	private String name;
	private String nameSpace;
	private String value;

	public FormElementAttribute() {
	}

	public FormElementAttribute(String name, String nameSpace, String value) {
		super();
		this.name = name;
		this.nameSpace = nameSpace;
		this.value = value;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getNameSpace() {
		return nameSpace;
	}

	public void setNameSpace(String nameSpace) {
		this.nameSpace = nameSpace;
	}

	public String getValue() {
		return value;
	}

	public void setValue(String value) {
		this.value = value;
	}

}
