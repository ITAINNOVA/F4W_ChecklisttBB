package es.itainnova.f4w.wp6.surveyTaker.data;

import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;

import es.itainnova.utilities.ITAINNOVAException;

public class FormInstanceElement {

	private static String NAME_KEY = "name";
	private static String VALUE_KEY = "value";

	private String name;
	private Object value;
	public static String ELEMENT_CANONICAL_NAME_SEPARATOR = "\\.";

	public FormInstanceElement() {
	}

	public FormInstanceElement(String name, Object value) throws ITAINNOVAException {
		super();
		setName(name);
		setValue(value);
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public Object getValue() {
		return this.value;
	}

	public void setValue(Object value) throws ITAINNOVAException {
		List<Object> valueElements;
		Object elementObject;
		List<FormInstanceElement> formInstanceElements = null;
		FormInstanceElement formInstanceElement;
		if ((value instanceof String)) {
			this.value = value;
		} else if (value instanceof byte[]) {
			this.value = value;
		} else if (value instanceof List<?>) {

			if (value != null) {
				if (((List) value).size() > 0) {
					valueElements = (List<Object>) value;
					formInstanceElements = new ArrayList<FormInstanceElement>();
					for (int i = 0; i < valueElements.size(); i++) {
						elementObject = valueElements.get(i);
						if (elementObject instanceof FormInstanceElement) {
							formInstanceElement = (FormInstanceElement) elementObject;
						} else {
							formInstanceElement = transformDeserializedObjectToFormInstanceElement(elementObject);
						}
						formInstanceElements.add(formInstanceElement);
					}
					this.value = formInstanceElements;
				} else {
					this.value = value;
				}

			}
		} else {
			if (value != null) {
				throw new ITAINNOVAException(
						"String and List<FormInstanceElement> are the only class allowed for FormInstance values.");
			}
		}
	}

	public String readStringValue() throws ITAINNOVAException {
		String stringValue = null;
		Object objectValue = this.getValue();
		List<FormInstanceElement> formInstanceElements;
		FormInstanceElement formInstanceElement;

		if (objectValue instanceof String) {
			stringValue = (String) objectValue;
		} else if (objectValue instanceof List<?>) {
			formInstanceElements = (List<FormInstanceElement>) objectValue;
			stringValue = "";
			for (int i = 0; i < formInstanceElements.size(); i++) {
				formInstanceElement = formInstanceElements.get(i);
				stringValue = stringValue.concat(" ").concat(formInstanceElement.readStringValue());
			}
		} else {
			if (objectValue != null) {
				throw new ITAINNOVAException(
						"Values of objects can only be of class String and List<FormInstanceElement>.  Actual class is:"
								+ objectValue.getClass().toString());
			}
		}
		value = this.getValue();

		return stringValue;
	}

	private FormInstanceElement transformDeserializedObjectToFormInstanceElement(Object deserializedObject)
			throws ITAINNOVAException {
		FormInstanceElement formInstanceElement = null;
		String name = null;
		String valueString = null;
		Object valueObject;
		LinkedHashMap<String, Object> linkedHashMap = (LinkedHashMap<String, Object>) deserializedObject;

		for (String key : linkedHashMap.keySet()) {
			if (key.equals(NAME_KEY)) {
				valueObject = linkedHashMap.get(key);
				if (valueObject instanceof String) {
					name = (String) valueObject;
				}
			}
			if (key.equals(VALUE_KEY)) {
				valueObject = linkedHashMap.get(key);
				if (valueObject == null) {
					formInstanceElement = new FormInstanceElement(name, null);
				} else if (valueObject instanceof String) {
					valueString = (String) valueObject;
					if (name != null) {
						formInstanceElement = new FormInstanceElement(name, valueString);
					}
				} else if (valueObject instanceof List<?>) {
					formInstanceElement = new FormInstanceElement(name, valueObject);
				} else {
					throw new ITAINNOVAException(
							"Allowed classes form element values are: String and List<FormInstanceElements>");
				}
			}
		}

		return formInstanceElement;
	}

	public void addElement(FormInstanceElement formInstanceElement) throws ITAINNOVAException {
		Object value;
		List<FormInstanceElement> listFormInstanceElements;

		value = this.getValue();
		if ((value == null) || (value instanceof List<?>)) {
			if (value == null) {
				listFormInstanceElements = new ArrayList<FormInstanceElement>();
				this.setValue(listFormInstanceElements);
			} else {
				listFormInstanceElements = (List<FormInstanceElement>) value;
			}
			listFormInstanceElements.add(formInstanceElement);
		} else {
			throw new ITAINNOVAException(
					"It is not possible to add a FormInstanceElement object.  The actual value of the element has class "
							+ value.getClass().getName() + ".");
		}

	}

	public String toJsonString(String tabs, Integer index) throws ITAINNOVAException {
		String jsonString = "";
		String tabs2;
		Object value;

		value = this.getValue();

		if (value != null) {
			if (index > 0)
			{
				jsonString=jsonString+ tabs+ "\t,\n";
			}
			tabs2 = tabs + "\t";
			jsonString = jsonString + tabs2 + "{\n";
			jsonString = jsonString + tabs2 + "\t\"name\":\"" + this.getName() + "\",\n";
			jsonString = jsonString + valueToJsonString(tabs2);
			jsonString = jsonString + tabs2 + "}\n";
		}
		return jsonString;
	}

	private String valueToJsonString(String tabs) throws ITAINNOVAException {
		String jsonString = "";
		String tabs2;
		Object value;
		List<FormInstanceElement> listObjects;
		Integer index;
		FormInstanceElement formInstanceElement;

		tabs2 = tabs;

		value = this.getValue();
		if (value == null) {
			throw new ITAINNOVAException("Not a null value is allowed here");
		} else if (value instanceof String) {
			jsonString = jsonString + tabs2 + "\t\"value\":\"" + (String) value + "\"\n";

		} else if (value instanceof List<?>) {
			listObjects = (List<FormInstanceElement>) value;
			jsonString = jsonString + tabs2 + "\t\"value\":\n";
			jsonString = jsonString + tabs2 + "\t[\n";
			for (index = 0; index < listObjects.size(); index++) {
				formInstanceElement = listObjects.get(index);
				jsonString = jsonString + formInstanceElement.toJsonString(tabs2 + "\t", index);
			}
			jsonString = jsonString + tabs2 + "\t]\n";
		} else {
			throw new ITAINNOVAException("Something wrong happens with the instace definition");
		}
		return jsonString;
	}

	/**
	 * Sear an element within the current element value matching the full cannonical name.  It's recursive.
	 * @param cannonicalName
	 * @return
	 */
	public FormInstanceElement searchElementByCanonicalName(String cannonicalName) {
		FormInstanceElement formInstanceElement= null;
		String[] splittedName;
		String restOfName;
		if ((cannonicalName!=null) && (cannonicalName.length()>0))
		{
			if (this.getName().equals(cannonicalName))
			{
				formInstanceElement = this;
			}
			else
			{	
				splittedName = cannonicalName.split(ELEMENT_CANONICAL_NAME_SEPARATOR);
				restOfName = FormInstanceElement.restOfName(splittedName);
				formInstanceElement= this.searchElementByName(splittedName[0]);
				if (formInstanceElement!=null)
				{
					if (!formInstanceElement.getName().equals(cannonicalName))
					{
						formInstanceElement = formInstanceElement.searchElementByCanonicalName(restOfName);
					}
				}
			}
			
		}


		return formInstanceElement;
	}
	
	public FormInstanceElement searchElementByName(String name)
	{
		FormInstanceElement formInstanceElement = null;
		Integer index = -1;
		Boolean found = false;
		Object value;
		List<FormInstanceElement> formInstanceElements;
		
		value = this.getValue();
		if (value instanceof List<?>)
		{
			formInstanceElements = (List<FormInstanceElement>)(value);
			if (formInstanceElements != null) {
				if ((formInstanceElements.size() > 0) && (name != null) && (name.length() > 0)) {
					for (index = 0; ((index < formInstanceElements.size()) && (!found)); index++) {
						formInstanceElement = formInstanceElements.get(index);
						if (name.equals(formInstanceElement.getName())) {
							found = true;
						}
					}
					if (!found) {
						formInstanceElement = null;
					}
				}
			}
		}
		return formInstanceElement;
	}

	public static String restOfName (String[] splittedName)
	{
		String returnedString="";
		Integer index;
		
		for (index =1;  index < splittedName.length; index++)
		{
			if (index>1)
			{
				returnedString= returnedString + FormInstanceElement.ELEMENT_CANONICAL_NAME_SEPARATOR.replace("\\", "");
			}
			returnedString+=returnedString + splittedName[index];
		}
		
		return returnedString;
	}
}
