package es.itainnova.f4w.wp6.surveyTaker.data;

import java.util.ArrayList;
import java.util.List;

import es.itainnova.utilities.ITAINNOVAException;

public class GetFormInstancesListServiceResponse extends ServiceResponse {
	
	String userToken;
	String formID;
	String instanceID;
	List<FormInstance> formList;

	public GetFormInstancesListServiceResponse() {
	}

	public GetFormInstancesListServiceResponse(String userToken, List<FormInstance> formList) {
		super(userToken);
		this.formList = formList;
	}

	public String getUserToken() {
		return userToken;
	}

	public void setUserToken(String userToken) {
		this.userToken = userToken;
	}

	public String getFormID() {
		return formID;
	}

	public void setFormID(String formID) {
		this.formID = formID;
	}

	public String getInstanceID() {
		return instanceID;
	}

	public void setInstanceID(String instanceID) {
		this.instanceID = instanceID;
	}

	public List<FormInstance> getFormList() {
		return formList;
	}

	public void setFormList(List<FormInstance> formList) {
		this.formList = formList;
	}
	
	
	public void addForm(FormInstance form)
	{
		if (this.formList  == null)
		{
			formList= new ArrayList<FormInstance>();
		}
		formList.add(form);
	}
	
	public String formInstancesListToJSON(String tabs) throws ITAINNOVAException
	{
		String jsonString;
		List <FormInstance> listFormInstances;
		Integer index;
		FormInstance formInstance;
		String tabs2;
		
		tabs2=tabs+"\t";
		listFormInstances = this.getFormList();
		jsonString = tabs2+ "{\n";
		jsonString = jsonString + tabs2+ "\t\"formList\":\n";
		jsonString = jsonString + tabs2+ "\t[\n";
		if (listFormInstances!= null)
		{
			for (index=0; index<listFormInstances.size(); index++)
			{
				formInstance = listFormInstances.get(index);
				if (index>0)
				{
					jsonString = jsonString + tabs2+ "\t,\n";
				}
				jsonString = jsonString + formInstance.toJSONString(tabs2);
			}			
		}
		jsonString = jsonString + tabs2+ "\t[\n";
		return jsonString;
	}

}
