package es.itainnova.f4w.wp6.surveyTaker.data.odkAccess;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Set;

import org.javarosa.core.model.FormDef;
import org.javarosa.core.model.IFormElement;
import org.javarosa.core.model.SubmissionProfile;
import org.javarosa.core.model.data.SelectMultiData;
import org.javarosa.core.model.data.helper.Selection;
import org.javarosa.core.model.instance.FormInstance;
import org.javarosa.core.model.instance.TreeElement;
import org.javarosa.core.model.instance.TreeReference;
import org.javarosa.core.services.locale.Localizer;
import org.javarosa.core.util.OrderedMap;
import org.javarosa.core.util.PrefixTreeNode;
import org.kxml2.kdom.Element;
import org.opendatakit.aggregate.constants.HtmlUtil;
import org.opendatakit.aggregate.constants.ServletConsts;
import org.opendatakit.aggregate.exception.ODKFormNotFoundException;
import org.opendatakit.aggregate.exception.ODKIncompleteSubmissionData;
import org.opendatakit.aggregate.form.FormFactory;
import org.opendatakit.aggregate.form.IForm;
import org.opendatakit.aggregate.servlet.FormXmlServlet;
import org.opendatakit.aggregate.servlet.XFormsManifestServlet;
import org.opendatakit.common.datamodel.BinaryContentManipulator;
import org.opendatakit.common.persistence.exception.ODKDatastoreException;
import org.opendatakit.common.persistence.exception.ODKOverQuotaException;
import org.opendatakit.common.web.CallingContext;
import org.opendatakit.common.web.constants.BasicConsts;

import es.itainnova.f4w.wp6.surveyTaker.data.Form;
import es.itainnova.f4w.wp6.surveyTaker.data.FormElement;
import es.itainnova.f4w.wp6.surveyTaker.data.FormElementAttribute;
import es.itainnova.f4w.wp6.surveyTaker.data.FormElementBinding;
import es.itainnova.f4w.wp6.surveyTaker.data.FormList;
import es.itainnova.f4w.wp6.surveyTaker.data.FormLocalizer;
import es.itainnova.f4w.wp6.surveyTaker.data.FormTranslation;
import es.itainnova.f4w.wp6.surveyTaker.data.FormTranslationText;
import es.itainnova.f4w.wp6.surveyTaker.data.FormValue;
import es.itainnova.f4w.wp6.surveyTaker.data.GetFormAttachmentServiceRequest;
import es.itainnova.f4w.wp6.surveyTaker.data.GetFormAttachmentServiceResponse;
import es.itainnova.utilities.ITAINNOVAException;

public class ODKForms {

	private final CallingContext cc;
	private final String downloadRequestURL;
	private final String manifestRequestURL;
	private final boolean verbose;

	public ODKForms(Boolean verbose, CallingContext cc) {
		super();

		String webServerUrl;
		webServerUrl = cc.getServerURL();
		this.cc = cc;
		this.downloadRequestURL = webServerUrl + BasicConsts.FORWARDSLASH + FormXmlServlet.ADDR;
		this.manifestRequestURL = webServerUrl + BasicConsts.FORWARDSLASH + XFormsManifestServlet.ADDR;
		this.verbose = verbose;
	}

	public FormList listForms(String formId, Boolean checkAuthorization) throws ITAINNOVAException {

		FormList itainnovaFormList = new FormList();
		Form itaInnovaForm;

		try {
			List<IForm> formsList = FormFactory.getForms(false, this.cc);
			if (formId != null && formId.length() != 0) {
				List<IForm> newList = new ArrayList<IForm>();
				for (IForm iForm : formsList) {
					if (iForm.getFormId().equals(formId)) {
						newList.add(iForm);
					}
				}
				formsList = newList;
			}
			for (IForm iForm : formsList) {
				itaInnovaForm = copyBasicGeneralPropertiesFromODKFormToF4WForm(iForm);
				itainnovaFormList.addForm(itaInnovaForm);
			}

		} catch (ODKOverQuotaException e) {
			throw new ITAINNOVAException(e.getMessage());
		} catch (ODKDatastoreException e) {
			throw new ITAINNOVAException(e.getMessage());
		}

		return itainnovaFormList;
	}

	public Form getForm(String formId, Boolean redeable, Boolean checkAuthorization) throws ITAINNOVAException {

		Form itaInnovaForm = null;

		IForm iForm;
		try {
			iForm = FormFactory.retrieveFormByFormId(formId, cc);
			itaInnovaForm = copyGeneralPropertiesFromODKFormToF4WForm(iForm);
			copyODKFields(itaInnovaForm, iForm, cc);

		} catch (ODKFormNotFoundException e) {
			throw new ITAINNOVAException(e.getMessage());
		} catch (ODKOverQuotaException e) {
			throw new ITAINNOVAException(e.getMessage());
		} catch (ODKDatastoreException e) {
			throw new ITAINNOVAException(e.getMessage());
		}

		return itaInnovaForm;
	}

	private Form copyBasicGeneralPropertiesFromODKFormToF4WForm(IForm iForm) throws ODKDatastoreException {
		Form itaInnovaForm = null;
		String formDescription;
		String formDownloadRequestURL;
		Map<String, String> properties;
		String manifesTURLLinK;
		String mediaFile = null;
		String fileName = null;
		String hash = null;
		BinaryContentManipulator manifest;
		Integer totalNumberOfAttachements;

		if (this.verbose) {
			formDescription = iForm.getDescription();
		} else {
			formDescription = null;
		}
		// Creating URLLink
		properties = new HashMap<String, String>();
		properties.put(ServletConsts.FORM_ID, iForm.getFormId());
		formDownloadRequestURL = HtmlUtil.createLinkWithProperties(this.downloadRequestURL, properties);
		// Creating manifesTURLLinK
		if (iForm.hasManifestFileset(this.cc)) {
			properties = new HashMap<String, String>();
			properties.put(ServletConsts.FORM_ID, iForm.getFormId());
			manifesTURLLinK = HtmlUtil.createLinkWithProperties(this.manifestRequestURL, properties);
			manifest = iForm.getManifestFileset();
			totalNumberOfAttachements = manifest.getAttachmentCount(cc);

		} else {
			manifesTURLLinK = null;
			totalNumberOfAttachements = 0;
		}

		itaInnovaForm = new Form(iForm.getFormId(), iForm.getViewableName(), iForm.getMajorMinorVersionString(),
				iForm.getOpenRosaVersionString(), iForm.getXFormFileHash(this.cc), formDescription,
				iForm.getDescriptionUrl(), formDownloadRequestURL, manifesTURLLinK, mediaFile, fileName, hash, null);
		itaInnovaForm.setTotalNumberOfAttachements(totalNumberOfAttachements);

		return itaInnovaForm;
	}

	private Form copyGeneralPropertiesFromODKFormToF4WForm(IForm iForm) throws ODKDatastoreException {
		Form itaInnovaForm = null;
		Map<String, String> properties;
		// Creating URLLink
		properties = new HashMap<String, String>();
		properties.put(ServletConsts.FORM_ID, iForm.getFormId());

		itaInnovaForm = copyBasicGeneralPropertiesFromODKFormToF4WForm(iForm);
		itaInnovaForm.setXml(iForm.getFormXml(cc));
		// TODO FJLP see how to fill this null values
		itaInnovaForm.setMediaFile(null);
		itaInnovaForm.setFileName(null);
		itaInnovaForm.setHash(null);
		return itaInnovaForm;
	}

	/**
	 * returns the attachment[index] of the form identified by formID
	 * 
	 * @param formId
	 * @param index
	 * @param redeable
	 * @param checkAuthorization
	 * @return
	 * @throws ITAINNOVAException
	 */
	public GetFormAttachmentServiceResponse getFormAttachment(String formId, Integer index,
			GetFormAttachmentServiceRequest getFormAttachmentServiceRequest, CallingContext cc, Boolean redeable,
			Boolean checkAuthorization) throws ITAINNOVAException {

		GetFormAttachmentServiceResponse getFormAttachmentServiceResponse;
		IForm iForm;
		BinaryContentManipulator manifest;
		Integer totalNumberOfAttachements;
		String unrootedFileName;
		String contentType;
		Long contentLength;
		byte[] blob;

		try {
			iForm = FormFactory.retrieveFormByFormId(formId, cc);
			manifest = iForm.getManifestFileset();
			if (manifest == null) {
				throw new ITAINNOVAException("Form: " + formId + " does not have attachements.");
			}
			if (index == null) {
				index = 1;
			}
			totalNumberOfAttachements = manifest.getAttachmentCount(cc);
			if ((index < 0) || (index > totalNumberOfAttachements)) {
				throw new ITAINNOVAException(
						"The index must be in the ranges [ 1, " + totalNumberOfAttachements + "]");
			}
			unrootedFileName = manifest.getUnrootedFilename(index, cc);
			contentType = manifest.getContentType(index, cc);
			contentLength = manifest.getContentLength(index, cc);
			blob = manifest.getBlob(index, cc);

		} catch (ODKFormNotFoundException e) {
			throw new ITAINNOVAException(e.getMessage());
		} catch (ODKOverQuotaException e) {
			throw new ITAINNOVAException(e.getMessage());
		} catch (ODKDatastoreException e) {
			throw new ITAINNOVAException(e.getMessage());
		}
		getFormAttachmentServiceResponse = new GetFormAttachmentServiceResponse(formId, totalNumberOfAttachements,
				index, unrootedFileName, contentType, contentLength, blob);
		return getFormAttachmentServiceResponse;
	}

	private void copyODKFields(Form itaInnovaForm, IForm iForm, CallingContext cc) throws ITAINNOVAException {
		String formTitle;
		ITAINNOVABaseFormParserForJavaRosa formParser;
		FormDef formDef;
		SubmissionProfile formSubmissionProfile;
		FormInstance formDataModel;
		TreeElement treeElement;

		formTitle = iForm.getViewableName();
		try {
			formParser = new ITAINNOVABaseFormParserForJavaRosa(itaInnovaForm.getXml(), formTitle, true);
		} catch (ODKIncompleteSubmissionData e) {
			throw new ITAINNOVAException(e.getMessage());
		}
		formDef = formParser.getFormDef();
		if (formDef == null) {
			throw new ITAINNOVAException(
					"Javarosa failed to construct a FormDef.  Something is wrong in the database for the form with ID:"
							+ itaInnovaForm.getFormID());
		}
		formSubmissionProfile = formDef.getSubmissionProfile();
		if (formSubmissionProfile != null) {
			itaInnovaForm
					.setSubmissionPublicKey(formSubmissionProfile.getAttribute(formParser.getBASE64_RSA_PUBLIC_KEY()));
		}
		formDataModel = formDef.getInstance();
		if (formDataModel == null) {
			throw new ITAINNOVAException(
					"Javarosa failed to construct a FormInstance.  Form defintion is not correctly load from database.");
		}

		treeElement = formDataModel.getRoot();
		itaInnovaForm.setRootFormElement(recursivelyCopyODKFields(formParser, treeElement, 0, formDef));
		itaInnovaForm.setLocalizer(copyODKLocalizer(formDef.getLocalizer()));
		itaInnovaForm.setFormField(formParser.getFormField());

	}

	private FormElement recursivelyCopyODKFields(ITAINNOVABaseFormParserForJavaRosa formParser, TreeElement treeElement,
			Integer level, FormDef formDef) throws ITAINNOVAException {
		String nodeName;
		String nodeNameSpace;
		String attributeName;
		String attributeNameSpace;
		String attributeNameValue;
		TreeElement treeElementChild;
		Element treeElementBinding;

		FormElement formElement, childFormElement;
		FormElementAttribute formElementAttribute;
		FormElementBinding binding;
		// List<FormElement> formElements;

		// formElements = new ArrayList<FormElement>();

		nodeName = treeElement.getName();
		nodeNameSpace = treeElement.getNamespace();
		if (nodeNameSpace == null) {
			nodeNameSpace = "";
		}

		formElement = new FormElement(nodeName, nodeNameSpace, getTreeElementValue(treeElement));

		// Tree element attributes
		for (int i = 0; i < treeElement.getAttributeCount(); i++) {
			attributeNameSpace = treeElement.getAttributeNamespace(i);
			if (attributeNameSpace != null && attributeNameSpace.length() == 0) {
				attributeNameSpace = "";
			}
			attributeName = treeElement.getAttributeName(i);
			attributeNameValue = treeElement.getAttributeValue(i);
			formElementAttribute = new FormElementAttribute(attributeName, attributeNameSpace, attributeNameValue);
			formElement.addAtribute(formElementAttribute);
		}

		// Tree element bindings
		List<Element> treeElementBindings = formParser.getBindingsForTreeElement(treeElement);
		for (int i = 0; i < treeElementBindings.size(); i++) {
			treeElementBinding = treeElementBindings.get(i);
			binding = new FormElementBinding();
			for (int j = 0; j < treeElementBinding.getAttributeCount(); j++) {
				attributeNameSpace = treeElementBinding.getAttributeNamespace(j);
				if (attributeNameSpace != null && attributeNameSpace.length() == 0) {
					attributeNameSpace = "";
				}
				attributeName = treeElementBinding.getAttributeName(j);
				attributeNameValue = treeElementBinding.getAttributeValue(j);
				formElementAttribute = new FormElementAttribute(attributeName, attributeNameSpace, attributeNameValue);
				binding.addAttribute(formElementAttribute);
			}
			formElement.addBingind(binding);
		}

		// Looking for the textId
		List<IFormElement> listFormElements;
		IFormElement iFormElement;
		String elementTextID;
		String elementPath;

		elementPath = formParser.getTreeElementPath(treeElement);
		elementPath = "/" + elementPath + ":label";
		listFormElements = formDef.getChildren();

		if (listFormElements != null) {
			for (int index = 0; index < listFormElements.size(); index++) {
				iFormElement = listFormElements.get(index);
				elementTextID = iFormElement.getTextID();
				if (elementTextID != null) {
					if (elementTextID.startsWith(elementPath)) {
						formElement.setTextID(elementTextID);
						break;
					}
				} else {
					formElement.setTextID(null);

				}
				// Copying default text
				formElement.setDefaultText(iFormElement.getLabelInnerText());

			}
		}

		// Copying childrens of the element
		for (Integer i = 0; i < treeElement.getNumChildren(); i++) {
			treeElementChild = treeElement.getChildAt(i);
			if (treeElementChild.isRepeatable()) {
				if (treeElementChild.getMult() != TreeReference.INDEX_TEMPLATE) {
					// treeElementTemplateDropCount++;
					continue;
				}
			}
			childFormElement = recursivelyCopyODKFields(formParser, treeElementChild, level + 1, formDef);
			formElement.addChild(childFormElement);
		}

		return formElement;

	}

	@SuppressWarnings("unused")
	private String recursivelyStringODKFields(ITAINNOVABaseFormParserForJavaRosa formParser, TreeElement treeElement,
			Integer level, FormDef formDef) {
		String tree;
		String nodeName;
		String nodeNameSpace;
		String nodePrefix = "";
		String attributePrefix;
		String attributeName;
		String attributeNameSpace;
		String attributeNameValue;
		TreeElement treeElementChild;
		Element treeElementBinding;
		String treeElementBindingAttibutePrefix;

		for (Integer i = 0; i < level; i++) {
			nodePrefix += "\t";
		}
		attributePrefix = nodePrefix + "\t";
		treeElementBindingAttibutePrefix = attributePrefix + "\t";

		nodeName = treeElement.getName();
		nodeNameSpace = treeElement.getNamespace();
		if (nodeNameSpace == null) {
			nodeNameSpace = "";
		}
		tree = "\n" + nodePrefix + "Tree Node Name:" + nodeName + "; Tree Node Name Space:" + nodeNameSpace;

		// Tree element attributes
		for (int i = 0; i < treeElement.getAttributeCount(); i++) {
			attributeNameSpace = treeElement.getAttributeNamespace(i);
			if (attributeNameSpace != null && attributeNameSpace.length() == 0) {
				attributeNameSpace = "";
			}
			attributeName = treeElement.getAttributeName(i);
			attributeNameValue = treeElement.getAttributeValue(i);
			tree = tree + "\n" + attributePrefix + "Tree Node Attribute Name Space:" + attributeNameSpace
					+ ";Tree Node Attribute Name:" + attributeName + ";Tree Noce Attribute Value: "
					+ attributeNameValue;
		}

		// get non-template entries for treeElement1
		for (Integer i = 0; i < treeElement.getNumChildren(); i++) {
			treeElementChild = treeElement.getChildAt(i);
			if (treeElementChild.isRepeatable()) {
				if (treeElementChild.getMult() != TreeReference.INDEX_TEMPLATE) {
					continue;
				}
			}
			tree = tree + recursivelyStringODKFields(formParser, treeElementChild, level + 1, formDef);
		}

		List<Element> treeElementBindings = formParser.getBindingsForTreeElement(treeElement);
		for (int i = 0; i < treeElementBindings.size(); i++) {
			treeElementBinding = treeElementBindings.get(i);
			tree = tree + "\n" + attributePrefix + "Binding Attibutes for the element:";
			for (int j = 0; j < treeElementBinding.getAttributeCount(); j++) {
				attributeNameSpace = treeElementBinding.getAttributeNamespace(j);
				if (attributeNameSpace != null && attributeNameSpace.length() == 0) {
					attributeNameSpace = "";
				}
				attributeName = treeElementBinding.getAttributeName(j);
				attributeNameValue = treeElementBinding.getAttributeValue(j);
				tree = tree + "\n" + treeElementBindingAttibutePrefix + "Tree Node Attribute Name Space:"
						+ attributeNameSpace + ";Tree Node Attribute Name:" + attributeName
						+ ";Tree Noce Attribute Value: " + attributeNameValue;
			}
		}

		return tree;
	}

	@SuppressWarnings("unused")
	private String getElementLabels(FormDef formDef, String elementPath, ITAINNOVABaseFormParserForJavaRosa formParser,
			TreeElement treeElement, Localizer formLocalizer) {
		String labels = null;
		int i;
		String currentLocale;
		String[] availableLocales;
		List<IFormElement> listFormElements;

		listFormElements = formDef.getChildren();

		if (listFormElements != null) {
			for (int index = 0; index < listFormElements.size(); index++) {
				labels = "labels transalations to different Languages; ";

			}
		}
		availableLocales = formLocalizer.getAvailableLocales();

		for (int index2 = 0; index2 < availableLocales.length; index2++) {
			currentLocale = availableLocales[index2];
			labels = labels + "language: " + currentLocale;
		}

		return labels;
	}

	private FormLocalizer copyODKLocalizer(Localizer iFormLocalizer) {
		FormLocalizer formLocalizer;
		FormTranslation formTranslation;
		FormTranslationText formTranslationText;
		FormValue formValue;

		OrderedMap<String, PrefixTreeNode> localeData;
		String[] availableLocales;
		String currentLanguage;
		List<FormElementAttribute> attributes;
		FormElementAttribute attribute;
		Set<String> labelsKeys;
		Iterator<String> labelsKeysIterator;
		String key;
		String label;

		String defaultLanguage;

		if (iFormLocalizer != null) {
			formLocalizer = new FormLocalizer();
			availableLocales = iFormLocalizer.getAvailableLocales();
			defaultLanguage = iFormLocalizer.getDefaultLocale();

			for (int index = 0; index < availableLocales.length; index++) {
				currentLanguage = availableLocales[index];
				attributes = new ArrayList<FormElementAttribute>();
				if (currentLanguage.contentEquals(defaultLanguage)) {
					attribute = new FormElementAttribute(FormTranslation.DEFAULT_ATTRIBUTE_NAME,
							FormTranslation.ATTRIBUTE_NAMESPACE, FormTranslation.DEFAULT_ATTIBUTE_VALUE);
					attributes.add(attribute);
				}
				attribute = new FormElementAttribute(FormTranslation.LANGUAGE_ATTRIBUTE_NAME,
						FormTranslation.ATTRIBUTE_NAMESPACE, currentLanguage);
				attributes.add(attribute);
				formTranslation = new FormTranslation(attributes, null);

				localeData = iFormLocalizer.getLocaleData(currentLanguage);
				labelsKeys = localeData.keySet();
				labelsKeysIterator = labelsKeys.iterator();
				while (labelsKeysIterator.hasNext()) {
					key = labelsKeysIterator.next();
					label = new String(localeData.get(key).getPrefix());
					attributes = new ArrayList<FormElementAttribute>();
					attribute = new FormElementAttribute(FormTranslationText.ID_NAME, FormTranslationText.ID_NAMESPACE,
							key);
					attributes.add(attribute);
					formValue = new FormValue(label);
					formTranslationText = new FormTranslationText(attributes, formValue);
					formTranslation.addText(formTranslationText);
				}

				formLocalizer.addTransalation(formTranslation);
			}
		} else {
			formLocalizer = null;
		}

		return formLocalizer;
	}

	private String getTreeElementValue(TreeElement treeElement) throws ITAINNOVAException {
		String value = null;
		Object nodeValue;
		nodeValue = treeElement.getValue();

		if ((nodeValue != null)) {
			if (nodeValue instanceof org.javarosa.core.model.data.IntegerData) {
				value = ((org.javarosa.core.model.data.IntegerData) nodeValue).getValue().toString();
			} else if (nodeValue instanceof org.javarosa.core.model.data.StringData) {
				value = ((org.javarosa.core.model.data.StringData) nodeValue).getValue().toString();
			} else if (nodeValue instanceof org.javarosa.core.model.data.DateData) {
				value = ((org.javarosa.core.model.data.DateData) nodeValue).getValue().toString();
			} else if (nodeValue instanceof org.javarosa.core.model.data.DateTimeData) {
				value = ((org.javarosa.core.model.data.DateTimeData) nodeValue).getValue().toString();
			} else if (nodeValue instanceof org.javarosa.core.model.data.DecimalData) {
				value = ((org.javarosa.core.model.data.DecimalData) nodeValue).getValue().toString();
			} else if (nodeValue instanceof org.javarosa.core.model.data.SelectOneData) {
				value = ((org.javarosa.core.model.data.SelectOneData) nodeValue).getValue().toString();
			} else if (nodeValue instanceof org.javarosa.core.model.data.SelectMultiData) {
				SelectMultiData selectMultiData = (org.javarosa.core.model.data.SelectMultiData) nodeValue;
				@SuppressWarnings("unchecked")
				ArrayList<Object> preselectedOptions = (ArrayList<Object>) selectMultiData.getValue();
				Selection selection;

				if ((preselectedOptions != null) && (!preselectedOptions.isEmpty())) {
					if ((preselectedOptions.get(0) instanceof Selection)) {
						value = "";
						for (int i = 0; i < preselectedOptions.size(); i++) {
							selection = (Selection) preselectedOptions.get(i);
							value += selection.xmlValue + " ";

						}
					} else {
						throw new ITAINNOVAException("Class: " + nodeValue.getClass().getName()
								+ " has not already implemented for be an option of multiple selection.");
					}
				}
			} else {
				throw new ITAINNOVAException(
						"Class: " + nodeValue.getClass().getName() + " has not already implemented.");
			}
		}

		return value;
	}

}
