package es.itainnova.f4w.wp6.surveyTaker.data;

public class GetFormInstancesListServiceRequest extends ServiceRequest {
	
	Boolean verbose;
	Boolean readable;
	String openRosaVersion;
	String formId;
	QueryFilterGroup queryFilterGroup;
	QueryProjection queryProjection;
	Integer fetchLimit;
	
	
	public GetFormInstancesListServiceRequest() {
		super();
	}
	public GetFormInstancesListServiceRequest(FormInstance formInstance, Boolean verbose, Boolean readable,
			String openRosaVersion, String formId,QueryFilterGroup queryFilterGroup, QueryProjection queryProjection,
			Integer fetchLimit) {
		super();
		this.verbose = verbose;
		this.readable = readable;
		this.openRosaVersion = openRosaVersion;
		this.formId = formId;
		this.queryFilterGroup = queryFilterGroup;
		this.queryProjection = queryProjection;
		this.fetchLimit= fetchLimit;
	}
	public Boolean getVerbose() {
		return verbose;
	}
	public void setVerbose(Boolean verbose) {
		this.verbose = verbose;
	}
	public Boolean getReadable() {
		return readable;
	}
	public void setReadable(Boolean readable) {
		this.readable = readable;
	}
	public String getOpenRosaVersion() {
		return openRosaVersion;
	}
	public void setOpenRosaVersion(String openRosaVersion) {
		this.openRosaVersion = openRosaVersion;
	}
	public String getFormId() {
		return formId;
	}
	public void setFormId(String formId) {
		this.formId = formId;
	}
	public QueryFilterGroup getQueryFilterGroup() {
		return queryFilterGroup;
	}
	public void setQueryFilterGroup(QueryFilterGroup queryFilterGroup) {
		this.queryFilterGroup = queryFilterGroup;
	}
	public QueryProjection getQueryProjection() {
		return queryProjection;
	}
	public void setQueryProjection(QueryProjection queryProjection) {
		this.queryProjection = queryProjection;
	}
	public Integer getFetchLimit() {
		return fetchLimit;
	}
	public void setFetchLimit(Integer fetchLimit) {
		this.fetchLimit = fetchLimit;
	}
	

}
