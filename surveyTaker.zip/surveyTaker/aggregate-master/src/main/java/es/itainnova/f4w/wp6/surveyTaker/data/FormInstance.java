package es.itainnova.f4w.wp6.surveyTaker.data;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

import es.itainnova.utilities.ITAINNOVAException;

public class FormInstance {

	public static String INSTANCE_NAME_KEY = "name";
	public static String FORM_ID_KEY = "id";
	public static String INSTANCE_ID_KEY = "instanceID";
	public static String VERSION_KEY = "version";
	public static String META_KEY = "meta";
	// TODO verify this values not found for the moment
	public static String VERSION_UI_KEY = "versionUI";
	public static String SUBMISSION_DATE_KEY = "submissionDate";
	public static String MARKED_AS_COMPLETED_DATE_KEY = "markedAsCompletedDate";

	/**
	 * Attibute values. Could be null
	 */
	private List<FormInstanceElement> attributes;

	/**
	 * Fields values. Could be null
	 */
	private List<FormInstanceElement> elements;

	public FormInstance() {
		super();

	}

	/**
	 * This param are mandatory attributes for the instance althouht for
	 * generalization they can be null The lastone in an element of the
	 * meta(data) of the instance
	 * 
	 * @param instanceName
	 * @param formID
	 * @param version
	 * @param elements
	 * @param instanceID
	 * @throws ITAINNOVAException 
	 */
	public FormInstance(List<FormInstanceElement> elements,
			List<FormInstanceElement> attributes) throws ITAINNOVAException {
		super();

		this.setElements(elements);
		this.setAttributes(attributes);
	}

	public FormInstance(String instanceName, String formID, String version, List<FormInstanceElement> elements
			) throws ITAINNOVAException {
		super();

		this.addAttribute(new FormInstanceElement(INSTANCE_NAME_KEY, instanceName));
		this.addAttribute(new FormInstanceElement(FORM_ID_KEY, formID));
		this.addAttribute(new FormInstanceElement(VERSION_KEY, version));
		this.setElements(elements);
	}

	
	public List<FormInstanceElement> getElements() {
		return elements;
	}

	public List<FormInstanceElement> getAttributes() {
		return this.attributes;
	}

	public void setAttributes(List<FormInstanceElement> attributes) {
		this.attributes = attributes;
	}

	public void setElements(List<FormInstanceElement> elements) {
		this.elements = elements;
	}

	public void addElement(FormInstanceElement formInstanceElement) {
		if (this.getElements() == null) {
			this.setElements(new ArrayList<FormInstanceElement>());
		}
		this.getElements().add(formInstanceElement);
	}

	public Boolean removeElement(String elementName) {
		FormInstanceElement formInstanceElement;
		List<FormInstanceElement> formInstanceElements;
		Iterator<FormInstanceElement> iterator;
		Boolean removed=false;
		if ((elementName!= null) && (elementName.length()>0))
		{
			formInstanceElements = this.getElements();
			if ((formInstanceElements!=null) && (formInstanceElements.size()>0))
			{
				iterator = formInstanceElements.iterator();
				while (iterator.hasNext() && !removed)
				{
					formInstanceElement = iterator.next();
					if (formInstanceElement.getName().equals(elementName))
					{
						iterator.remove();
						removed=true;
					}
				}
			}
						
		}
		return removed;
	}

	
	public void addAttribute(FormInstanceElement formInstanceElement) {
		if (this.getAttributes() == null) {
			this.setAttributes(new ArrayList<FormInstanceElement>());
		}
		this.getAttributes().add(formInstanceElement);
	}

	public void addMetaElement(FormInstanceElement formInstanceElement) throws ITAINNOVAException {
		FormInstanceElement meta;
		Object metaObjectValue;
		List<FormInstanceElement> formInstanceMetaElements;
		meta = (FormInstanceElement) this.getElementByNameFromList(META_KEY, this.getElements());
		if (meta == null) {
			meta = new FormInstanceElement(META_KEY, new ArrayList<FormInstanceElement>());
			this.addElement(meta);
		}
		metaObjectValue = meta.getValue();
		if (metaObjectValue instanceof String) {
			throw new ITAINNOVAException("meta field of an instances is a group of values not a single one");
		}
		if (metaObjectValue instanceof FormInstanceElement) {
			throw new ITAINNOVAException("meta field of an instances is a group of values not a single one");
		}
		formInstanceMetaElements = (List<FormInstanceElement>) metaObjectValue;
		if (formInstanceMetaElements == null) {
			formInstanceMetaElements = new ArrayList<FormInstanceElement>();
		}
		formInstanceMetaElements.add(formInstanceElement);
	}

	public FormInstanceElement getAttributeByName(String name) {

		return this.getElementByNameFromList(name, this.getAttributes());
	}

	public FormInstanceElement getElementByName(String name) {

		return this.getElementByNameFromList(name, this.getElements());
	}

	public FormInstanceElement getElementByNameFromList(String name, List<FormInstanceElement> formInstanceElements) {
		FormInstanceElement formInstanceElement = null;
		Integer index = -1;
		Boolean found = false;
		if (formInstanceElements != null) {
			if ((formInstanceElements.size() > 0) && (name != null) && (name.length() > 0)) {
				for (index = 0; ((index < formInstanceElements.size()) && (!found)); index++) {
					formInstanceElement = formInstanceElements.get(index);
					if (name.equals(formInstanceElement.getName())) {
						found = true;
					}
				}
				if (!found) {
					formInstanceElement = null;
				}
			}
		}

		return formInstanceElement;
	}

	public List<FormInstanceElement> setAttributeValue(String elementName, String elementValue) throws ITAINNOVAException {

		List<FormInstanceElement> formInstanceElements = this.getAttributes();
		FormInstanceElement formInstanceElement;
		if ((elementName != null) && (elementName.length() > 0)) {
			if (formInstanceElements == null) {
				formInstanceElements = new ArrayList<FormInstanceElement>();
				formInstanceElement = new FormInstanceElement(elementName, elementValue);
				formInstanceElements.add(formInstanceElement);
			}
			else
			{
				formInstanceElement = (FormInstanceElement) this.getElementByNameFromList(elementName, formInstanceElements);
				formInstanceElement.setValue(elementValue);
			}
		}
		return formInstanceElements;
	}

	public List<FormInstanceElement> setElementValue(String elementName, Object elementValue,
			List<FormInstanceElement> formInstanceElements) throws ITAINNOVAException {

		FormInstanceElement formInstanceElement;
		if ((elementName != null) && (elementName.length() > 0)) {
			if (formInstanceElements == null) {
				formInstanceElements = new ArrayList<FormInstanceElement>();
			}
			if (elementValue instanceof String) {
				formInstanceElement = new FormInstanceElement(elementName, (String) elementValue);
			} else if (elementValue instanceof List<?>)
			{
				formInstanceElement = new FormInstanceElement(elementName, (List<FormInstanceElement>) elementValue);
			}
			else
			{
					throw new ITAINNOVAException("FormInstanceElement value can only be String of List<FormInstanceElement>");
			}
			formInstanceElements.add(formInstanceElement);
		}
		else 
		{
			throw new ITAINNOVAException("A name must be provided for setting the element value.");
		}
		return formInstanceElements;
	}

	public String toJSONString(String tabs) throws ITAINNOVAException
	{
		String jsonString;
		String tabs2;
		
		tabs2= tabs + "\t";
		
		jsonString = tabs2 +"{\n";
		jsonString = jsonString + tabs2 + "\t\t\"attributes\":\n";
		jsonString = jsonString + this.listOfFormInstanceElementsToString(this.getAttributes(), tabs2+"\t");
		jsonString = jsonString + tabs2 + "\t},\n";
		jsonString = jsonString + tabs2 + "\t{\n";
		jsonString = jsonString + tabs2 + "\t\t\"elements\":\n";
		jsonString = jsonString + this.listOfFormInstanceElementsToString(this.getElements(), tabs2+"\t");
		jsonString = jsonString + tabs2 +"\t}\n";
		
		return jsonString;
		
	}
	
	private String listOfFormInstanceElementsToString(List<FormInstanceElement> listFormInstanceElements, String tabs) throws ITAINNOVAException
	{
		String jsonString=tabs;
		Integer index;
		FormInstanceElement formInstanceElement;
		String tabs2;
		
		tabs2=tabs+"\t";
		jsonString=tabs2+"[\n";
		if (listFormInstanceElements!=null)
		{
			for (index=0; index<listFormInstanceElements.size(); index++)
			{
				formInstanceElement = listFormInstanceElements.get(index);
				jsonString=jsonString+ formInstanceElement.toJsonString(tabs2, index);
			}
		}
		jsonString=jsonString + tabs2+ "]\n";
		return jsonString;
	}
	
	public FormInstanceElement searchElementByCanonicalName(String canonicalName)
	{
		FormInstanceElement foundFormInstanceElement=null;
		String[] splittedName;
		Object value;
		String restOfName;
		Integer index;
		List<FormInstanceElement> formInstanceElements;
	
		
		if ((canonicalName!=null) && (canonicalName.length()>0))
		{
			splittedName = canonicalName.split(FormInstanceElement.ELEMENT_CANONICAL_NAME_SEPARATOR);
			restOfName = FormInstanceElement.restOfName(splittedName);
			foundFormInstanceElement = this.getElementByName(splittedName[0]);
			if (foundFormInstanceElement!= null)
			{
				if (!foundFormInstanceElement.getName().equals(canonicalName))
				{
					foundFormInstanceElement = foundFormInstanceElement.searchElementByCanonicalName(restOfName);
				}
			}
		}
		
		return foundFormInstanceElement;
	}
	
}
