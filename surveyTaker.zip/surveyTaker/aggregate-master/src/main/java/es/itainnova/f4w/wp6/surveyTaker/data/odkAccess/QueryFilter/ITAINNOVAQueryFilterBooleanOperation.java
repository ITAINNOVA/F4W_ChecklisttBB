package es.itainnova.f4w.wp6.surveyTaker.data.odkAccess.QueryFilter;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;

import es.itainnova.utilities.ITAINNOVAException;

public class ITAINNOVAQueryFilterBooleanOperation implements ITAINNOVAQueryFilterTrueValueInterface {

	private static String TRUE_VALUE_ARGUMENT1_JSON_STRING = "trueValueArgument1";
	private static String TRUE_VALUE_ARGUMENT2_JSON_STRING = "trueValueArgument2";
	private static String BOOLEAN_OPERATOR_JSON_STRING = "booleanOperator";

	Object trueValueArgument1;
	Object trueValueArgument2;
	ITAINNOVAQueryFilterBooleanOpearator booleanOperator;

	
	public ITAINNOVAQueryFilterBooleanOperation() {
		super();
	}

	public ITAINNOVAQueryFilterBooleanOperation(Object trueValueArgument1,
			Object trueValueArgument2,
			ITAINNOVAQueryFilterBooleanOpearator booleanOperator) {
		super();
		this.trueValueArgument1 = trueValueArgument1;
		this.trueValueArgument2 = trueValueArgument2;
		this.booleanOperator = booleanOperator;
	}

	public Object getTrueValueArgument1() {
		return trueValueArgument1;
	}

	public void setTrueValueArgument1(Object trueValueArgument1) throws ITAINNOVAException {
		this.trueValueArgument1 = this.extractTrueValueArgumentValue(trueValueArgument1);
	}

	public Object getTrueValueArgument2() {
		return trueValueArgument2;
	}

	public void setTrueValueArgument2(Object trueValueArgument2) throws ITAINNOVAException {
		this.trueValueArgument2 = this.extractTrueValueArgumentValue(trueValueArgument2);;
	}

	public ITAINNOVAQueryFilterBooleanOpearator getBooleanOperator() {
		return booleanOperator;
	}

	public void setBooleanOperator(ITAINNOVAQueryFilterBooleanOpearator booleanOperator) {
		this.booleanOperator = booleanOperator;
	}

	@Override
	public Boolean evaluateTrueValue() throws ITAINNOVAException {

		return this.evaluateTrueValue(false);
	}

	@Override
	public Boolean evaluateTrueValue(Boolean considerUnderlyingClass) throws ITAINNOVAException {
		Boolean trueValue = false;
		Boolean trueValue1;
		Boolean trueValue2;
		Object argument1, argument2;
		ITAINNOVAQueryFilterBooleanOpearator operator;
		
		argument1= this.getTrueValueArgument1();
		argument2= this.getTrueValueArgument2();
		operator = this.getBooleanOperator();
		trueValue1= this.evaluateArgumentTrueValue(argument1);
		trueValue2= this.evaluateArgumentTrueValue(argument2);

		if ((operator==null) && (argument1==null) && (argument2==null))
		{
				trueValue = null;
				
		}
		if ((operator==null) && (argument1!=null))
		{
				trueValue = trueValue1;
		}
		if ((operator!=null))
		{
			switch (this.booleanOperator) {
			case NOT:
			{
				// Argument2 is ignored
				trueValue = !trueValue1;
				break;
			}
			case AND:
			{
				trueValue = trueValue1 && trueValue2;
				break;
			}
			case OR:
			{
				trueValue = trueValue1 || trueValue2;
				break;
			}
			default:
				throw new ITAINNOVAException(this.booleanOperator.getStringRepresentation()
						+ " is not currently implemented by " + this.getClass().getCanonicalName());
			}
		}
		return trueValue;
	}
	
	private Boolean evaluateArgumentTrueValue(Object argument) throws ITAINNOVAException
	{
		Boolean trueValue= false;
		
		if (argument instanceof ITAINNOVAQueryFilterBooleanValue)
		{
			trueValue = ((ITAINNOVAQueryFilterBooleanValue)argument).evaluateTrueValue();
		}
		else if(argument instanceof ITAINNOVAQueryFilterBooleanOperation)
		{
			trueValue = ((ITAINNOVAQueryFilterBooleanOperation)argument).evaluateTrueValue();
		}
		else if(argument instanceof ITAINNOVAQueryFilterBinnaryComparisonOperation)
		{
			trueValue = ((ITAINNOVAQueryFilterBinnaryComparisonOperation)argument).evaluateTrueValue();
		}

		
		return trueValue;
	}

	public List<String> extractArguments()
	{
		List<String> arguments;
		Object argument;
		
		arguments = new ArrayList<String>();
		
		argument = this.getTrueValueArgument1();
		if (argument instanceof String)
		{
			arguments.add((String)argument);
		}
		else
		{
			if (argument instanceof ITAINNOVAQueryFilterBooleanOperation)
			{
				arguments.addAll(((ITAINNOVAQueryFilterBooleanOperation)argument).extractArguments());
			}
			else if (argument instanceof ITAINNOVAQueryFilterBinnaryComparisonOperation)
			{
				arguments.addAll(((ITAINNOVAQueryFilterBinnaryComparisonOperation)argument).extractArguments());
			}
		}
	
		return arguments;
	}
	
	private static Object extractTrueValueArgumentValue (Object argument) throws ITAINNOVAException
	{
		Object value= null;
		Boolean extractedBinaryComparison = true;
		Boolean extractedBoolean = true;
		if (argument instanceof LinkedHashMap<?,?>){
			//TODO they could be Boolean, Binnary comparison operations or nothing interesting
			try {
				if (ITAINNOVAQueryFilterBinnaryComparisonOperation.isITAINNOVAQueryFilterBinnaryComparisonOperation(
						(LinkedHashMap<String,Object>)argument))
				{
					value = ITAINNOVAQueryFilterBinnaryComparisonOperation.
							convertJSONtoTAINNOVAQueryFilterBinnaryComparisonOperation((LinkedHashMap<String,Object>)argument);
				}
			} catch (ITAINNOVAException e) {
				extractedBinaryComparison= false;
			}

			try {
				if ((!extractedBinaryComparison) && (ITAINNOVAQueryFilterBooleanOperation.isITAINNOVAQueryFilterBooleanOperation(
						(LinkedHashMap<String,Object>)argument)))
				{
					value = ITAINNOVAQueryFilterBooleanOperation.
							convertJSONtoTAINNOVAQueryFilterBooleanOperation((LinkedHashMap<String,Object>)argument);
				}
			} catch (ITAINNOVAException e) {
				extractedBoolean  = false;
			}
			if (!(extractedBinaryComparison || extractedBoolean))
			{
				throw new ITAINNOVAException("The argument could not be converted neither to a "
						+ "Binary Comparison Operation or to a Boolean Operation");
			}

		}
		else if ((argument instanceof String))
		{
			value = ITAINNOVAQueryFilterBooleanValue.giveMeTheBooleanTypeValue(argument);
		}
		else if ((argument instanceof ITAINNOVAQueryFilterBinnaryComparisonOperation)
				|| (argument instanceof ITAINNOVAQueryFilterBooleanOperation)
				|| (argument instanceof ITAINNOVAQueryFilterBooleanValue))
		{
			value = argument;
		}
		else
		{
			throw new ITAINNOVAException("The given trueValueArgument: "+ argument+ " is not supported by the current version.");
		}
		return value;
	}
	
	public static Boolean isITAINNOVAQueryFilterBooleanOperation(LinkedHashMap<String, Object> linkedHashMap)
			throws ITAINNOVAException {
		Boolean isRequiredType = true;
		Object valueObject;

		if (linkedHashMap == null) {
			throw new ITAINNOVAException("Null can not be converted to a Boolean Operation");
		}

		for (String key : linkedHashMap.keySet()) {
			if (!((key.equals(TRUE_VALUE_ARGUMENT1_JSON_STRING) || key.equals(TRUE_VALUE_ARGUMENT2_JSON_STRING)
					|| key.equals(BOOLEAN_OPERATOR_JSON_STRING)))) {
				throw new ITAINNOVAException("The argument field names does not match the supported one by the"
						+ " current version of ITAINNOVAQueryFilterBinnaryComparisonOperation.");
			}
			valueObject = linkedHashMap.get(key);
			if (valueObject!=null)
			{
				if (!((valueObject instanceof String) || (valueObject instanceof LinkedHashMap<?,?>)))
				{
					throw new ITAINNOVAException("The class of the value:" + valueObject.getClass()+
							" is not supported by the current version of ITAINNOVAQueryFilterBinnaryComparisonOperation.");
				}
			}
		}
		return isRequiredType;

	}

	public static ITAINNOVAQueryFilterBooleanOperation convertJSONtoTAINNOVAQueryFilterBooleanOperation(
			LinkedHashMap<String, Object> linkedHashMap) throws ITAINNOVAException {
		ITAINNOVAQueryFilterBooleanOperation value = null;
		Object valueObject;
		Object argument1=null, argument2=null, operator=null;

		if (linkedHashMap != null) {
			for (String key : linkedHashMap.keySet()) {
				valueObject = linkedHashMap.get(key);
				if (key.equals(TRUE_VALUE_ARGUMENT1_JSON_STRING))
				{
					argument1 = ITAINNOVAQueryFilterBooleanOperation.getJSONFieldValue(key, valueObject);
				}
				else if( key.equals(TRUE_VALUE_ARGUMENT2_JSON_STRING))
				{
					argument2 = ITAINNOVAQueryFilterBooleanOperation.getJSONFieldValue(key, valueObject);
				}
				else if( key.equals(BOOLEAN_OPERATOR_JSON_STRING))
				{
					operator = ITAINNOVAQueryFilterBooleanOperation.getJSONFieldValue(key, valueObject);
				}
				else
				{
					throw new ITAINNOVAException("The argument field names does not match the supported one by the"
							+ " current version of ITAINNOVAQueryFilterBinnaryComparisonOperation.");
				}
			}
			value = new ITAINNOVAQueryFilterBooleanOperation(argument1, argument2,
					(ITAINNOVAQueryFilterBooleanOpearator)operator);
		}

		return value;

	}

	private static Object getJSONFieldValue(String argumentKey, Object argumentValue) throws ITAINNOVAException {
		Object value = null;
		
		if (argumentKey.equals(TRUE_VALUE_ARGUMENT1_JSON_STRING) ||( argumentKey.equals(TRUE_VALUE_ARGUMENT2_JSON_STRING)))
		{
			if (argumentValue instanceof String)
			{
				value = ITAINNOVAQueryFilterBooleanValue.giveMeTheBooleanTypeValue(argumentValue);
			}
			else if (argumentValue instanceof LinkedHashMap<?,?>)
			{
				value = ITAINNOVAQueryFilterBooleanOperation.extractTrueValueArgumentValue(argumentValue);
			}
			else {
				throw new ITAINNOVAException("The class:" + argumentValue.getClass().getCanonicalName() +
						 " is not supported an argument type by the current version of ITAINNOVAQueryFilterBinnaryComparisonOperation.");
			}
		}
		else if( argumentKey.equals(BOOLEAN_OPERATOR_JSON_STRING))
		{
			if (argumentValue instanceof String)
			{
				value = ITAINNOVAQueryFilterBooleanOpearator.
						giveMeBooleanOperatorFromJSONrepresentation( (String)argumentValue);
			}
			else
			{
				throw new ITAINNOVAException("Just an String can be used for represent a Binnary operation in JSON");
			}
		}
		

		return value;
	}


	@Override
	public ITAINNOVAQueryFilterBooleanOperation clone()
	{	
		ITAINNOVAQueryFilterBooleanOperation cloned=null;
		Object clonedArgument1;
		Object clonedArgument2;
		Object clonedOperator;
		
		clonedArgument1 = this.cloneArgument(this.getTrueValueArgument1());
		clonedArgument2 = this.cloneArgument(this.getTrueValueArgument2());
		clonedOperator = this.cloneOperator(this.getBooleanOperator());
		
		cloned = new ITAINNOVAQueryFilterBooleanOperation(clonedArgument1, clonedArgument2, 
				(ITAINNOVAQueryFilterBooleanOpearator)clonedOperator);
		return cloned;
	}


	private Object cloneArgument(Object argument) {
		Object clonedArgument = null;

		if (argument!=null)
		{
			if (argument instanceof String)
			{
				clonedArgument = new String(((String)argument));
			}
			else if (argument instanceof ITAINNOVAQueryFilterBooleanValue)
			{
				clonedArgument = argument;
			}
			else if (argument instanceof ITAINNOVAQueryFilterBinnaryComparisonOperation)
			{
				clonedArgument = ((ITAINNOVAQueryFilterBinnaryComparisonOperation)argument).clone();
			}
			else if (argument instanceof ITAINNOVAQueryFilterBooleanOperation)
			{
				clonedArgument = ((ITAINNOVAQueryFilterBooleanOperation)argument).clone();
			}
		}
		return clonedArgument;
	}

	private Object cloneOperator(ITAINNOVAQueryFilterBooleanOpearator booleanOperator2) {
		ITAINNOVAQueryFilterBooleanOpearator clonedOperator = null;

		if (booleanOperator2!=null)
		{
			clonedOperator = booleanOperator2;
		}
		return clonedOperator;
	}

	public ITAINNOVAQueryFilterBooleanOperation createFilterReplacingColumnNamesByValues
		(HashMap<String, String> keyValues) throws ITAINNOVAException {
		// TODO Auto-generated method stub
		
		ITAINNOVAQueryFilterBooleanOperation clonedFilter;
		Set kyeValueSet;
		Iterator iterator;

		clonedFilter = this.clone();
		kyeValueSet = keyValues.entrySet();
	    iterator = kyeValueSet.iterator();
	    while(iterator.hasNext()) {
	         Map.Entry<String, String> mentry = (Map.Entry<String, String>)iterator.next();
	         clonedFilter.replaceColumnNameByValue(mentry.getKey(),mentry.getValue());
	    }
		return clonedFilter;
	}
	private Object replaceColumnNameByValue(String key, String value) throws ITAINNOVAException {
		this.setTrueValueArgument1(
				this.replaceColumnNameByValueArgument(this.getTrueValueArgument1(), key, value));
		this.setTrueValueArgument2(
				this.replaceColumnNameByValueArgument(this.getTrueValueArgument2(), key, value));
		return this;
	}

	private Object replaceColumnNameByValueArgument(Object argument, String key, String value) throws ITAINNOVAException {
		if (argument instanceof String)
		{
			if (value==null)
			{
				return ((String) argument).replace(key, "null");
			}
			else
			{
				return ((String) argument).replace(key, value);
			}
		}
		else if (argument instanceof ITAINNOVAQueryFilterBinnaryComparisonOperation)
		{
			return ((ITAINNOVAQueryFilterBinnaryComparisonOperation)argument).replaceColumnNameByValue(key,value);
		}
		else if (argument instanceof ITAINNOVAQueryFilterBooleanOperation)
		{
			return ((ITAINNOVAQueryFilterBooleanOperation)argument).replaceColumnNameByValue(key,value);
		}
		return argument;
	}

}
