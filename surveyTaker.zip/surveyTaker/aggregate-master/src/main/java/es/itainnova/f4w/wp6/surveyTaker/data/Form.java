package es.itainnova.f4w.wp6.surveyTaker.data;

import java.util.ArrayList;
import java.util.List;

public class Form {
	
	private String formID;
	private Integer totalNumberOfAttachements;
	private String viewableName;
	private String majorMinorVersion;
	private String openRosaVersion;
	private String xFormFileHash;
	private String description;
	private String descriptionURL;
	private String downloadUrl;
	private String manifestUrl;
	private String mediaFile;
	private String fileName;
	private String hash;
	private String xml;
	private String submissionPublicKey;

	private List<FormElement> formElements;
	private FormElement rootFormElement;
	private FormLocalizer localizer;
	private FormField formField;

	public Form() {
		super();
	}

	// TODO delete this method after testing implementation
	public Form(String formID) {
		super();
		this.formID = formID;
		formField = null;
	}

	public Form(String formID, String viewableName, String majorMinorVersion, String openRosaVersion,
			String xFormFileHash, String description, String descriptionURL, String downloadUrl, String manifestUrl,
			String mediaFile, String fileName, String hash, String xml) {
		super();
		this.formID = formID;
		this.viewableName = viewableName;
		this.majorMinorVersion = majorMinorVersion;
		this.openRosaVersion = openRosaVersion;
		this.xFormFileHash = xFormFileHash;
		this.description = description;
		this.descriptionURL = descriptionURL;
		this.downloadUrl = downloadUrl;
		this.manifestUrl = manifestUrl;
		this.mediaFile = mediaFile;
		this.fileName = fileName;
		this.hash = hash;
		this.xml = xml;
		this.formElements = new ArrayList<FormElement>();
		this.formField = null;
		this.rootFormElement = null;
	}

	public String getFormID() {
		return formID;
	}

	public void setFormID(String formID) {
		this.formID = formID;
	}

	public Integer getTotalNumberOfAttachements() {
		return totalNumberOfAttachements;
	}

	public void setTotalNumberOfAttachements(Integer totalNumberOfAttachements) {
		this.totalNumberOfAttachements = totalNumberOfAttachements;
	}

	public String getViewableName() {
		return viewableName;
	}

	public void setViewableName(String viewableName) {
		this.viewableName = viewableName;
	}

	public String getMajorMinorVersion() {
		return majorMinorVersion;
	}

	public void setMajorMinorVersion(String majorMinorVersion) {
		this.majorMinorVersion = majorMinorVersion;
	}

	public String getOpenRosaVersion() {
		return openRosaVersion;
	}

	public void setOpenRosaVersion(String openRosaVersion) {
		this.openRosaVersion = openRosaVersion;
	}

	public String getxFormFileHash() {
		return xFormFileHash;
	}

	public void setxFormFileHash(String xFormFileHash) {
		this.xFormFileHash = xFormFileHash;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public String getDescriptionURL() {
		return descriptionURL;
	}

	public void setDescriptionURL(String descriptionURL) {
		this.descriptionURL = descriptionURL;
	}

	public String getDownloadUrl() {
		return downloadUrl;
	}

	public void setDownloadUrl(String downloadUrl) {
		this.downloadUrl = downloadUrl;
	}

	public String getManifestUrl() {
		return manifestUrl;
	}

	public void setManifestUrl(String manifestUrl) {
		this.manifestUrl = manifestUrl;
	}

	public String getMediaFile() {
		return mediaFile;
	}

	public void setMediaFile(String mediaFile) {
		this.mediaFile = mediaFile;
	}

	public String getFileName() {
		return fileName;
	}

	public void setFileName(String fileName) {
		this.fileName = fileName;
	}

	public String getHash() {
		return hash;
	}

	public void setHash(String hash) {
		this.hash = hash;
	}

	/*
	 * public String getXml() { return xml; }
	 * 
	 * public void setXml(String xml) { this.xml = xml; }
	 */
	public String getSubmissionPublicKey() {
		return submissionPublicKey;
	}

	public void setSubmissionPublicKey(String submissionPublicKey) {
		this.submissionPublicKey = submissionPublicKey;
	}

	public String getXml() {
		return xml;
	}

	public void setXml(String xml) {
		this.xml = xml;
	}

	public FormField getFormField() {
		return formField;
	}

	public void setFormField(FormField formField) {
		this.formField = formField;
	}

	public List<FormElement> getFormElements() {
		return formElements;
	}

	public void setFormElements(List<FormElement> formElements) {
		this.formElements = formElements;
	}

	public FormElement getRootFormElement() {
		return rootFormElement;
	}

	public void setRootFormElement(FormElement rootFormElement) {
		this.rootFormElement = rootFormElement;
	}

	public FormLocalizer getLocalizer() {
		return localizer;
	}

	public void setLocalizer(FormLocalizer localizer) {
		this.localizer = localizer;
	}


}
