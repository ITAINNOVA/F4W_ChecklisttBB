package es.itainnova.f4w.wp6.surveyTaker.data;

public class GetFormAttachmentServiceResponse extends ServiceResponse {
	
	private String formID;
	private Integer totalNumberofAttachments;
	private Integer attachmentIndex;
    private String unrootedFileName;
    private String contentType;
    private Long contentLength;
	private byte[] blob;

	public GetFormAttachmentServiceResponse() {
		super();
	}


	public GetFormAttachmentServiceResponse(String formID, Integer totalNumberofAttachments, Integer attachmentIndex,
			String unrootedFileName, String contentType, Long contentLength, byte[] blob) {
		super();
		this.formID = formID;
		this.totalNumberofAttachments = totalNumberofAttachments;
		this.attachmentIndex = attachmentIndex;
		this.unrootedFileName = unrootedFileName;
		this.contentType = contentType;
		this.contentLength = contentLength;
		this.blob = blob;
	}

	public String getFormID() {
		return formID;
	}

	public void setFormID(String formID) {
		this.formID = formID;
	}

	public Integer getTotalNumberofAttachments() {
		return totalNumberofAttachments;
	}

	public void setTotalNumberofAttachments(Integer totalNumberofAttachments) {
		this.totalNumberofAttachments = totalNumberofAttachments;
	}

	public Integer getAttachmentIndex() {
		return attachmentIndex;
	}

	public void setAttachmentIndex(Integer attachmentIndex) {
		this.attachmentIndex = attachmentIndex;
	}

	public String getUnrootedFileName() {
		return unrootedFileName;
	}


	public void setUnrootedFileName(String unrootedFileName) {
		this.unrootedFileName = unrootedFileName;
	}


	public String getContentType() {
		return contentType;
	}


	public void setContentType(String contentType) {
		this.contentType = contentType;
	}


	public Long getContentLength() {
		return contentLength;
	}


	public void setContentLength(Long contentLength) {
		this.contentLength = contentLength;
	}


	public byte[] getBlob() {
		return blob;
	}

	public void setBlob(byte[] blob) {
		this.blob = blob;
	}


}
