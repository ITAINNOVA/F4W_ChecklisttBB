package es.itainnova.f4w.wp6.surveyTaker.data;

import java.util.ArrayList;
import java.util.List;

public class FormLocalizer {
	
	List<FormElementAttribute> attributes;
	List<FormTranslation> itext;
	

	public FormLocalizer() {
		
	}


	public FormLocalizer(List<FormElementAttribute> attributes, List<FormTranslation> itext) {
		super();
		this.attributes = attributes;
		this.itext = itext;
	}


	public List<FormElementAttribute> getAttributes() {
		return attributes;
	}


	public void setAttributes(List<FormElementAttribute> attributes) {
		this.attributes = attributes;
	}


	public List<FormTranslation> getItext() {
		return itext;
	}


	public void setItext(List<FormTranslation> itext) {
		this.itext = itext;
	}
	
	public void addTransalation(FormTranslation formTranslation)
	{
		if (this.itext == null)
		{
			this.itext = new ArrayList<FormTranslation>();
		}
		this.itext.add(formTranslation);
		
	}

}
