package es.itainnova.f4w.wp6.surveyTaker.data;

public class QueryUIResumePoint {

	private static final long serialVersionUID = 7500161085826059616L;
	private String attributeName;
	private String value;
	private String uriLastReturnedValue;
	private Boolean isForwardCursor;

	public QueryUIResumePoint() {
		super();
	}

	public QueryUIResumePoint(String attributeName, String value, String uriLastReturnedValue,
			Boolean isForwardCursor) {
		super();
		this.attributeName = attributeName;
		this.value = value;
		this.uriLastReturnedValue = uriLastReturnedValue;
		this.isForwardCursor = isForwardCursor;
	}

	public String getAttributeName() {
		return attributeName;
	}

	public void setAttributeName(String attributeName) {
		this.attributeName = attributeName;
	}

	public String getValue() {
		return value;
	}

	public void setValue(String value) {
		this.value = value;
	}

	public String getUriLastReturnedValue() {
		return uriLastReturnedValue;
	}

	public void setUriLastReturnedValue(String uriLastReturnedValue) {
		this.uriLastReturnedValue = uriLastReturnedValue;
	}

	public Boolean getIsForwardCursor() {
		return isForwardCursor;
	}

	public void setIsForwardCursor(Boolean isForwardCursor) {
		this.isForwardCursor = isForwardCursor;
	}

	public static long getSerialversionuid() {
		return serialVersionUID;
	}

}
