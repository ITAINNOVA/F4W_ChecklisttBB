package es.itainnova.f4w.wp6.surveyTaker.data;

import java.util.ArrayList;
import java.util.List;

public class FormField {
	
	public FormField(String name, String nameSpace, String value) {
		super();
		this.name = name;
		this.nameSpace = nameSpace;
		this.value = value;
	}
	List<FormElementAttribute> attributes;
	String name; 
	String nameSpace;
	String value;

	List<FormField>  fields;
	
	public FormField() {
	}
	
	public List<FormElementAttribute> getAttributes() {
		return attributes;
	}
	public void setAttributes(List<FormElementAttribute> attributes) {
		this.attributes = attributes;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getNameSpace() {
		return nameSpace;
	}
	public void setNameSpace(String nameSpace) {
		this.nameSpace = nameSpace;
	}
	public String getValue() {
		return value;
	}
	public void setValue(String value) {
		this.value = value;
	}
	public List<FormField> getFields() {
		return fields;
	}
	public void setFields(List<FormField> fields) {
		this.fields = fields;
	}

	public void  addAttribute(FormElementAttribute attribute)
	{
		if (this.attributes == null)
		{
			this.attributes = new ArrayList<FormElementAttribute>();
		}
		this.attributes.add(attribute);
	}
	
	public void addFormField (FormField formField)
	{
		if (this.fields == null)
		{
			this.fields = new ArrayList<FormField>();
		}
		this.fields.add(formField);
	}
}
