package es.itainnova.f4w.wp6.surveyTaker.data;

import java.util.ArrayList;
import java.util.List;

public class FormElementBinding {

	List<FormElementAttribute> attributes;

	public FormElementBinding() {
	}
		
	public List<FormElementAttribute> getAttributes() {
		return attributes;
	}

	public void setAttributes(List<FormElementAttribute> attributes) {
		this.attributes = attributes;
	}
	
	public void addAttribute(FormElementAttribute attribute)
	{
		if (this.attributes==null)
		{
			this.attributes = new ArrayList<FormElementAttribute>();
		}
		this.attributes.add(attribute);
	}

		

}
