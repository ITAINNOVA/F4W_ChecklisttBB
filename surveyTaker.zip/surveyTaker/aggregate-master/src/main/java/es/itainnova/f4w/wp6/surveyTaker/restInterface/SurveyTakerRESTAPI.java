package es.itainnova.f4w.wp6.surveyTaker.restInterface;

import java.util.List;

import javax.servlet.ServletContext;
import javax.servlet.http.HttpServletRequest;

import org.opendatakit.aggregate.ContextFactory;
import org.opendatakit.common.web.CallingContext;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import es.itainnova.f4w.wp6.surveyTaker.data.FormInstance;
import es.itainnova.f4w.wp6.surveyTaker.data.FormInstanceElement;
import es.itainnova.f4w.wp6.surveyTaker.data.GetFormAttachmentServiceRequest;
import es.itainnova.f4w.wp6.surveyTaker.data.GetFormAttachmentServiceResponse;
import es.itainnova.f4w.wp6.surveyTaker.data.GetFormInstanceBinnaryServiceRequest;
import es.itainnova.f4w.wp6.surveyTaker.data.GetFormInstanceBinnaryServiceResponse;
import es.itainnova.f4w.wp6.surveyTaker.data.GetFormInstancesListServiceRequest;
import es.itainnova.f4w.wp6.surveyTaker.data.GetFormInstancesListServiceResponse;
import es.itainnova.f4w.wp6.surveyTaker.data.GetFormServiceRequest;
import es.itainnova.f4w.wp6.surveyTaker.data.GetFormServiceResponse;
import es.itainnova.f4w.wp6.surveyTaker.data.ListFormsServiceRequest;
import es.itainnova.f4w.wp6.surveyTaker.data.ListFormsServiceResponse;
import es.itainnova.f4w.wp6.surveyTaker.data.PostFulfilledFormServiceRequest;
import es.itainnova.f4w.wp6.surveyTaker.data.PostFulfilledFormServiceResponse;
import es.itainnova.f4w.wp6.surveyTaker.data.odkAccess.FormInstanceBinnary;
import es.itainnova.f4w.wp6.surveyTaker.data.odkAccess.ITAINNOVAFormInstanceSubmision;
import es.itainnova.f4w.wp6.surveyTaker.data.odkAccess.ODKForms;
import es.itainnova.utilities.ITAINNOVAException;

//TODO ITANNOVA all methods should use the userToken to verify access permissions on forms

@RestController
@RequestMapping("/")
public class SurveyTakerRESTAPI  {

	@Autowired
	private ServletContext context;
	/**
	* 
	*/
	private ODKForms odkForms;
	//TODO review where it is supposed to be obtained ...
	private Boolean checkAuthorization = false;

	@RequestMapping(value = "/listForms", method = RequestMethod.POST, headers = "Accept=application/json")
	public ListFormsServiceResponse listForms(@RequestBody ListFormsServiceRequest listFormServiceRequest,
			HttpServletRequest req) throws ITAINNOVAException {
		//ODKForms odkForms;
		CallingContext cc = ContextFactory.getCallingContext(context, req);
		ListFormsServiceResponse listFormsServiceResponse = new ListFormsServiceResponse();

		odkForms = new ODKForms(listFormServiceRequest.getVerbose(), cc);
		listFormsServiceResponse.setUserToken(listFormServiceRequest.getUserToken());
		listFormsServiceResponse.setFormList(odkForms.listForms(listFormServiceRequest.getFormID(), checkAuthorization));

		return listFormsServiceResponse;
	}

	@RequestMapping(value = "/getForm", method = RequestMethod.POST, headers = "Accept=application/json")
	public GetFormServiceResponse getForm(@RequestBody GetFormServiceRequest getFormServiceRequest,
			HttpServletRequest req) throws ITAINNOVAException {
		//ODKForms odkForms;
		CallingContext cc = ContextFactory.getCallingContext(context, req);
		GetFormServiceResponse getFormServiceResponse = new GetFormServiceResponse();
		Boolean redeable = getFormServiceRequest.getReadable();

		odkForms = new ODKForms(getFormServiceRequest.getVerbose(), cc);
		getFormServiceResponse.setUserToken(getFormServiceRequest.getUserToken());
	
		getFormServiceResponse.setForm(odkForms.getForm(getFormServiceRequest.getFormID(), redeable, checkAuthorization));

		return getFormServiceResponse;
	}

	@RequestMapping(value = "/getFormAttachment", method = RequestMethod.POST, headers = "Accept=application/json")
	public GetFormAttachmentServiceResponse getFormAttachement(@RequestBody GetFormAttachmentServiceRequest getFormAttachmentServiceRequest,
			HttpServletRequest req) throws ITAINNOVAException {
		//ODKForms odkForms;
		CallingContext cc = ContextFactory.getCallingContext(context, req);
		Boolean redeable = getFormAttachmentServiceRequest.getReadable();
		String formId = getFormAttachmentServiceRequest.getFormID();
		Integer index = getFormAttachmentServiceRequest.getIndex();
		
		odkForms = new ODKForms(getFormAttachmentServiceRequest.getVerbose(), cc);
		return odkForms.getFormAttachment(formId, index, getFormAttachmentServiceRequest, cc, redeable, checkAuthorization);
	}

	
	@GetMapping(value = "/hello/{id}")
	public String hello(@PathVariable String id) {
		String result = "Hello " + id;
		return result;
	}

	@RequestMapping(value = "/postFulfilledForm", method = RequestMethod.POST, headers = "Accept=application/json")
	public PostFulfilledFormServiceResponse postFulfilledForm(@RequestBody PostFulfilledFormServiceRequest postFulfilledFormServiceRequest,
			HttpServletRequest req) throws ITAINNOVAException {
		//ODKForms odkForms;
		CallingContext cc = ContextFactory.getCallingContext(context, req);
		Boolean redeable = postFulfilledFormServiceRequest.getReadable();
		FormInstance formInstance = postFulfilledFormServiceRequest.getFormInstance();
		PostFulfilledFormServiceResponse postFulfilledFormServiceResponse;
		ITAINNOVAFormInstanceSubmision instanceSubmision;
		Boolean isIncomplete = postFulfilledFormServiceRequest.getIsMultipart();
		Double openRosaVersion;
		
		try
		{
			openRosaVersion = new Double(postFulfilledFormServiceRequest.getOpenRosaVersion());
		}
		catch (Exception e)
		{
			throw new ITAINNOVAException(e.getMessage());
		}
		
		instanceSubmision = new ITAINNOVAFormInstanceSubmision();
		instanceSubmision.submitForm(formInstance, isIncomplete, openRosaVersion, cc, req);
		
		postFulfilledFormServiceResponse = new PostFulfilledFormServiceResponse();
		odkForms = new ODKForms(postFulfilledFormServiceRequest.getVerbose(), cc);
		postFulfilledFormServiceResponse.setFormList(odkForms.listForms(null, checkAuthorization));
		postFulfilledFormServiceResponse.setUserToken(postFulfilledFormServiceRequest.getUserToken());
		
		
		return postFulfilledFormServiceResponse;
	}

	@RequestMapping(value = "/formInstancesList", method = RequestMethod.POST, headers = "Accept=application/json")
	public GetFormInstancesListServiceResponse getFormInstancesList(@RequestBody GetFormInstancesListServiceRequest getFormInstancesListServiceRequest,
			HttpServletRequest req) throws ITAINNOVAException {
		CallingContext cc;
		GetFormInstancesListServiceResponse getFormInstancesListServiceResponse;
		List<FormInstance> listFormInstances;
		ITAINNOVAFormInstanceSubmision instanceSubmision;
		
		cc = ContextFactory.getCallingContext(context, req);

		instanceSubmision = new ITAINNOVAFormInstanceSubmision();
		listFormInstances = instanceSubmision.getFormInstancesSubmissionList(getFormInstancesListServiceRequest, cc);
		getFormInstancesListServiceResponse = new GetFormInstancesListServiceResponse();
		getFormInstancesListServiceResponse.setFormList(listFormInstances);
		getFormInstancesListServiceResponse.setUserToken(getFormInstancesListServiceRequest.getUserToken());
		
		
		return getFormInstancesListServiceResponse;
	}

	@RequestMapping(value = "/formInstanceGetBinnary", method = RequestMethod.POST, headers = "Accept=application/json")
	public GetFormInstanceBinnaryServiceResponse getFormInstanceGetBinnary(@RequestBody GetFormInstanceBinnaryServiceRequest getFormInstanceBinnaryServiceRequest,
			HttpServletRequest req) throws ITAINNOVAException {
		CallingContext cc;
		GetFormInstanceBinnaryServiceResponse getFormInstanceBinnaryServiceResponse;
		List<FormInstanceElement> blobFormInstanceElement;
		FormInstanceBinnary formInstanceBlob;
		
		String fileName=null;
		
		cc = ContextFactory.getCallingContext(context, req);

		formInstanceBlob = new FormInstanceBinnary();
		blobFormInstanceElement = formInstanceBlob.getBlob(getFormInstanceBinnaryServiceRequest.getValueURI(),
				getFormInstanceBinnaryServiceRequest.getName(),
				getFormInstanceBinnaryServiceRequest.getFormID(), cc);
		
		getFormInstanceBinnaryServiceResponse = new GetFormInstanceBinnaryServiceResponse();
		getFormInstanceBinnaryServiceResponse.setBlob(blobFormInstanceElement);
		getFormInstanceBinnaryServiceResponse.setUserToken(getFormInstanceBinnaryServiceRequest.getUserToken());
		getFormInstanceBinnaryServiceResponse.setFormID(getFormInstanceBinnaryServiceRequest.getFormID());
		getFormInstanceBinnaryServiceResponse.setFormInstanceID(getFormInstanceBinnaryServiceRequest.getFormInstanceID());
		if (blobFormInstanceElement!=null)
		{
			fileName = (String)blobFormInstanceElement.get(0).searchElementByCanonicalName(
				FormInstanceBinnary.UNROOTEDFILENAME_ELEMENT_NAME).getValue();
		}
		getFormInstanceBinnaryServiceResponse.setName(fileName);
		
		
		return getFormInstanceBinnaryServiceResponse;
	}

	
}
