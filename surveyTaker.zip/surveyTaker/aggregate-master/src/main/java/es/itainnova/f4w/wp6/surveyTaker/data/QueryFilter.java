package es.itainnova.f4w.wp6.surveyTaker.data;

public class QueryFilter {

	protected String uri; // unique identifier
	private Long ordinal; // order to display in filter group

	public QueryFilter() {
		super();
	}

	public QueryFilter(String uri, Long ordinal) {
		super();
		this.uri = uri;
		this.ordinal = ordinal;
	}

	public String getUri() {
		return uri;
	}

	public void setUri(String uri) {
		this.uri = uri;
	}

	public Long getOrdinal() {
		return ordinal;
	}

	public void setOrdinal(Long ordinal) {
		this.ordinal = ordinal;
	}
}
