package es.itainnova.f4w.wp6.surveyTaker.data;

import java.util.ArrayList;
import java.util.List;

import es.itainnova.utilities.ITAINNOVAException;

public class GetFormInstanceBinnaryServiceResponse extends ServiceResponse {
	
	String userToken;
	String formID;
	String formInstanceID;
	String name;
	List<FormInstanceElement> blob;
	byte[] bLOB;

	public GetFormInstanceBinnaryServiceResponse() {
	}

	
	public GetFormInstanceBinnaryServiceResponse(String userToken, String formID, String name,
			List<FormInstanceElement> blob) {
		super();
		this.userToken = userToken;
		this.formID = formID;
		this.name = name;
		this.blob = blob;
	}


	public String getUserToken() {
		return userToken;
	}


	public void setUserToken(String userToken) {
		this.userToken = userToken;
	}


	public String getFormID() {
		return formID;
	}


	public void setFormID(String formID) {
		this.formID = formID;
	}


	public String getFormInstanceID() {
		return formInstanceID;
	}


	public void setFormInstanceID(String formInstanceID) {
		this.formInstanceID = formInstanceID;
	}


	public String getName() {
		return name;
	}


	public void setName(String name) {
		this.name = name;
	}


	public List<FormInstanceElement> getBlob() {
		return blob;
	}


	public void setBlob(List<FormInstanceElement> blob) {
		this.blob = blob;
	}


	public byte[] getbLOB() {
		return bLOB;
	}


	public void setbLOB(byte[] bLOB) {
		this.bLOB = bLOB;
	}

}
