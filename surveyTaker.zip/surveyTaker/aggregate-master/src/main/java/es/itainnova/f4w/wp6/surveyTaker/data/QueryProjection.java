package es.itainnova.f4w.wp6.surveyTaker.data;

import java.util.ArrayList;
import java.util.List;

public class QueryProjection {
	
	List<String> projectionFields;

	public QueryProjection() {
		super();
	}

	public QueryProjection(List<String> projectionFields) {
		super();
		this.projectionFields = projectionFields;
	}

	public List<String> getProjectionFields() {
		return projectionFields;
	}

	public void setProjectionFields(List<String> projectionFields) {
		this.projectionFields = projectionFields;
	}
	
	public void addFieldNameToProjection (String fieldName)
	{
		if (this.projectionFields==null)
		{
			this.projectionFields = new ArrayList<String>();
		}
		this.projectionFields.add(fieldName);
	}
	

}
