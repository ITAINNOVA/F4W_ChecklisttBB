package es.itainnova.f4w.wp6.surveyTaker.data.odkAccess;

import java.io.OutputStream;
import java.io.UnsupportedEncodingException;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import javax.servlet.http.HttpServletResponse;

import org.opendatakit.aggregate.client.submission.Column;
import org.opendatakit.aggregate.client.submission.SubmissionUI;
import org.opendatakit.aggregate.client.submission.SubmissionUISummary;
import org.opendatakit.aggregate.constants.BeanDefs;
import org.opendatakit.aggregate.constants.ErrorConsts;
import org.opendatakit.aggregate.constants.ServletConsts;
import org.opendatakit.aggregate.constants.common.UIConsts;
import org.opendatakit.aggregate.datamodel.FormElementModel;
import org.opendatakit.aggregate.exception.ODKFormNotFoundException;
import org.opendatakit.aggregate.form.IForm;
import org.opendatakit.aggregate.form.PersistentResults;
import org.opendatakit.aggregate.form.PersistentResults.ResultFileInfo;
import org.opendatakit.aggregate.format.Row;
import org.opendatakit.aggregate.format.element.ElementFormatter;
import org.opendatakit.aggregate.format.element.UiElementFormatter;
import org.opendatakit.aggregate.server.GenerateHeaderInfo;
import org.opendatakit.aggregate.submission.Submission;
import org.opendatakit.aggregate.submission.SubmissionElement;
import org.opendatakit.aggregate.submission.SubmissionKey;
import org.opendatakit.aggregate.submission.SubmissionKeyPart;
import org.opendatakit.aggregate.submission.SubmissionSet;
import org.opendatakit.aggregate.submission.type.BlobSubmissionType;
import org.opendatakit.aggregate.submission.type.RepeatSubmissionType;
import org.opendatakit.aggregate.util.ImageUtil;
import org.opendatakit.common.persistence.exception.ODKDatastoreException;
import org.opendatakit.common.persistence.exception.ODKOverQuotaException;
import org.opendatakit.common.utils.WebUtils;
import org.opendatakit.common.web.CallingContext;
import org.opendatakit.common.web.constants.HtmlConsts;

import es.itainnova.f4w.wp6.surveyTaker.data.FormInstanceElement;
import es.itainnova.f4w.wp6.surveyTaker.data.QueryProjection;
import es.itainnova.utilities.ITAINNOVAException;
import es.itainnova.utilities.ITAINNOVAExceptionSubmisionFieldNotRequired;

public class FormInstanceElementExtension extends FormInstanceElement {

	private static String MATCHING_FIELD_NAME_TEMPLATE = "(.*:)*C*L*MN_N*M*";
	private static String MATCHING_FIELD_NAME_TEMPLATE_TO_REPLACE = "C*L*MN_N*M*";
	private static String MATCHING_META_FIELD_NAME_TEMPLATE = "^\\*meta.*\\*$";
	private static String MATCHING_PATH_TO_FIELD_NAME_TEMPLATE = "^P*TH_T*_F**LD|^P*TH_T*_F**LD\\..*";
	private static String MATCHING_PATH_TO_FIELD_NAME_TEMPLATE_TO_REPLACE = "P*TH_T*_F**LD";
	private static String NAME_PATH_SEPARATOR=".";
	// 20170306 FJLP cuando saco lo de los datos binarios para que vaya m�s r�pido
	//private static String BINARY_URI_SEPARATOR="blobKey=";

	FormInstanceElementExtension() {
		super();
	}

	public FormInstanceElementExtension(String name, Object value) throws ITAINNOVAException {
		super();
		setName(name);
		setValue(value);
	}

	public FormInstanceElementExtension(FormInstanceElement formInstanceElement) throws ITAINNOVAException {
		super();
		setName(formInstanceElement.getName());
		setValue(formInstanceElement.getValue());
	}

	/***
	 * This method is specially created for adding metadata other than
	 * instanceID
	 * 
	 * @param form
	 * @param node
	 * @param submissionUI
	 * @param listColumns
	 * @param prefix
	 * @throws ITAINNOVAException
	 * @throws ITAINNOVAExceptionSubmisionFieldNotRequired
	 */
	public FormInstanceElementExtension(IForm form, FormElementModel node, SubmissionUI submissionUI,
			List<Column> listColumns, CallingContext cc) throws ITAINNOVAException {

		super();

		List<FormElementModel> listElementModels;
		FormElementModel child;
		Integer index;
		FormInstanceElementExtension childFormInstanceElementExtension;
		FormInstanceElement childFormInstanceElement;

		String name;

		if (node == null) {
			throw new ITAINNOVAException(
					"Something wrong happens with the definition of the Form:" + form.getViewableName());
		}
		name = node.getElementName();
		this.setName(name);
		listElementModels = node.getChildren();
		if ((listElementModels == null) || (listElementModels.size() == 0)) {
			this.setValue(this.getValueFromSumbission(name, form, node, submissionUI, listColumns,cc));
		} else {
			for (index = 0; index < listElementModels.size(); index++) {
				child = listElementModels.get(index);
				childFormInstanceElementExtension = new FormInstanceElementExtension(form, child, submissionUI,
						listColumns,cc);
				childFormInstanceElement = new FormInstanceElement(childFormInstanceElementExtension.getName(),
						childFormInstanceElementExtension.getValue());
				this.addElement(childFormInstanceElement);
			}
		}
	}

	/**
	 * This method is specially create to support "normal" elements in
	 * particular groups, repeats, ...
	 * 
	 * @param form
	 * @param node
	 * @param submissionUI
	 * @param listColumns
	 * @param prefix
	 * @param queryProjection
	 * @throws ITAINNOVAException
	 * @throws ITAINNOVAExceptionSubmisionFieldNotRequired
	 */
	public FormInstanceElementExtension(IForm form, FormElementModel node, SubmissionUI submissionUI,
			List<Column> listColumns, String prefix, QueryProjection queryProjection, Boolean addInstanceMetadata,
			CallingContext cc) throws ITAINNOVAException, ITAINNOVAExceptionSubmisionFieldNotRequired {

		super();

		List<FormElementModel> listElementModels;
		FormElementModel child;
		Integer index;
		FormInstanceElementExtension childFormInstanceElementExtension;
		FormInstanceElement childFormInstanceElement;
		String groupPrefix;
		String namewithPrefix;

		String name;

		if (node == null) {
			throw new ITAINNOVAException(
					"Something wrong happens with the definition of the Form:" + form.getViewableName());
		}
		if ((prefix == null) || (prefix.length() == 0)) {
			groupPrefix = "";
		} else {
			groupPrefix = prefix + NAME_PATH_SEPARATOR;
		}
		name = node.getElementName();
		namewithPrefix = groupPrefix + name;
		if (addElementToResult(namewithPrefix, queryProjection)) {
			this.setName(name);
			switch (node.getElementType()) {
			case REPEAT: {
				/*
				 * this.setRepeatValue(name, namewithPrefix, form, node,
				 * submissionUI, listColumns, queryProjection,
				 * addInstanceMetadata, cc);
				 */
				throw new ITAINNOVAException("A repeat should not have to be found here ....");
			}
			default: {
				listElementModels = node.getChildren();
				if ((listElementModels == null) || (listElementModels.size() == 0)) {
					this.setValue(this.getValueFromSumbission(name, form, node, submissionUI, listColumns, cc));
				} else {
					groupPrefix = groupPrefix + name;
					for (index = 0; index < listElementModels.size(); index++) {
						child = listElementModels.get(index);
						switch (child.getElementType()) {
						case REPEAT: {
							this.setRepeatValue(child.getElementName(), namewithPrefix, form, child, submissionUI,
									listColumns, queryProjection, addInstanceMetadata, cc);
							break;
						}
						default: {
							childFormInstanceElementExtension = new FormInstanceElementExtension(form, child,
									submissionUI, listColumns, groupPrefix, queryProjection, addInstanceMetadata, cc);
							childFormInstanceElement = new FormInstanceElement(
									childFormInstanceElementExtension.getName(),
									childFormInstanceElementExtension.getValue());
							this.addElement(childFormInstanceElement);
						}
						}
					}
				}
			}
			}
		}
	}

	private Boolean addElementToResult(String nodeName, QueryProjection queryProjection)
			throws ITAINNOVAExceptionSubmisionFieldNotRequired {
		Boolean add = true;
		List<String> fields;
		Integer index;
		String fieldToConsider;
		String pathToFielToValidate;

		if (nodeName.matches(MATCHING_META_FIELD_NAME_TEMPLATE)) {
			add = false;
		}
		if (queryProjection != null) {
			fields = queryProjection.getProjectionFields();
			if ((fields != null)) {
				add = false;
				pathToFielToValidate = MATCHING_PATH_TO_FIELD_NAME_TEMPLATE
						.replace(MATCHING_PATH_TO_FIELD_NAME_TEMPLATE_TO_REPLACE, nodeName);
				for (index = 0; ((index < fields.size()) && (!add)); index++) {
					fieldToConsider = fields.get(index);
					if (fieldToConsider.matches(pathToFielToValidate)) {
						add = true;
					}
				}
			}
		}
		if (!add) {
			throw new ITAINNOVAExceptionSubmisionFieldNotRequired("");
		}

		return add;
	}

	private void setRepeatValue(String name, String prefix, IForm form, FormElementModel node,
			SubmissionUI submissionUI, List<Column> listColumns, QueryProjection queryProjection,
			Boolean addInstanceMetadata, CallingContext cc) throws ITAINNOVAException {

		String keyString;
		Object value;

		SubmissionKey repeatSumbissionKey;
		List<SubmissionKeyPart> parts;
		Submission repeatSumbimision;
		SubmissionElement tmp;
		RepeatSubmissionType repeat;
		SubmissionUISummary repeatSummary = null;
		GenerateHeaderInfo headerGenerator;
		List<FormElementModel> filteredElements;
		ElementFormatter elemFormatter;

		List<FormInstanceElement> repeatFormInstanceElements;
		Integer index;
		FormInstanceElement repeatFormInstanceElement;

		value = this.getValueFromSumbission(name, form, node, submissionUI, listColumns,cc);
		if (value!=null)
		{
		if ((value instanceof String)) {
			keyString = (String) value;
		} else {
			throw new ITAINNOVAException("Form Instance: " + submissionUI.getSubmissionKeyAsString()
					+ ".  The recovered value for the repeat field " + name + " is not an String.");
		}
		if ((keyString != null) || (keyString.length() > 0)) {

			try {
				repeatSumbissionKey = new SubmissionKey(keyString);
				parts = repeatSumbissionKey.splitSubmissionKey();
				if (!form.hasValidFormDefinition()) {
					throw new ITAINNOVAException(ErrorConsts.FORM_DEFINITION_INVALID); // ill-formed
																						// definition
				}
				repeatSumbimision = Submission.fetchSubmission(parts, cc);

				if (repeatSumbimision != null) {
					tmp = repeatSumbimision.resolveSubmissionKey(parts);
					repeat = (RepeatSubmissionType) tmp;

					repeatSummary = new SubmissionUISummary(form.getViewableName());
					headerGenerator = new GenerateHeaderInfo(null, repeatSummary, form);
					headerGenerator.processForHeaderInfo(repeat.getElement());
					filteredElements = headerGenerator.getIncludedElements();
					elemFormatter = new UiElementFormatter(cc.getServerURL(), headerGenerator.getGeopointIncludes());

					// format row elements
					for (SubmissionSet subSet : repeat.getSubmissionSets()) {
						Row row = subSet.getFormattedValuesAsRow(filteredElements, elemFormatter, false, cc);
						try {
							repeatSummary.addSubmission(new SubmissionUI(row.getFormattedValues(), null));
						} catch (Exception e) {
							e.printStackTrace();
						}
					}
					repeatFormInstanceElements = this.copyValuesToFormInstanceFromRepeatSubmisions(name, prefix, form,
							node, repeatSummary, queryProjection, addInstanceMetadata, cc);
					if (repeatFormInstanceElements!=null)
					{
						for (index=0; index<repeatFormInstanceElements.size();index++)
						{
							repeatFormInstanceElement = repeatFormInstanceElements.get(index);
							this.addElement(repeatFormInstanceElement);
						}
					}
				}

			} catch (Exception e) {
				throw new ITAINNOVAException(e.getMessage());
			}
		}
		}
	}

	private List<FormInstanceElement> copyValuesToFormInstanceFromRepeatSubmisions(String name, String prefix,
			IForm form, FormElementModel node, SubmissionUISummary summary, QueryProjection queryProjection,
			Boolean addInstanceMetadata, CallingContext cc)
			throws ITAINNOVAException, ITAINNOVAExceptionSubmisionFieldNotRequired {
		List<FormInstanceElement> listFormInstancesSubmission = null;
		List<FormInstanceElement> listFormRepeatSubelements = null;
		List<SubmissionUI> listSubmissionUIs;
		List<Column> listColumns;
		SubmissionUI submissionUI;
		Integer index;
		FormInstanceElementExtension repeatElementExtension;
		FormInstanceElement repeatElement;
		String nameWithPrefix;

		if ((form != null) && (summary != null)) {
			listFormInstancesSubmission = new ArrayList<FormInstanceElement>();
			listColumns = summary.getHeaders();
			listSubmissionUIs = summary.getSubmissions();
			nameWithPrefix=prefix+NAME_PATH_SEPARATOR+name;
			for (index = 0; index < listSubmissionUIs.size(); index++) {
				submissionUI = listSubmissionUIs.get(index);
				listFormRepeatSubelements = this.getValuesToFormInstanceFromRepeatSubmision(name, nameWithPrefix, listColumns,
						form, node, submissionUI, queryProjection, addInstanceMetadata, cc);
				repeatElement = new FormInstanceElement(name,listFormRepeatSubelements); 
				listFormInstancesSubmission.add(repeatElement);
			}
		}

		return listFormInstancesSubmission;
	}

	private List<FormInstanceElement> getValuesToFormInstanceFromRepeatSubmision(String name, String prefix,
			List<Column> listColumns, IForm form, FormElementModel node, SubmissionUI submissionUI,
			QueryProjection queryProjection, Boolean addInstanceMetadata, CallingContext cc)
			throws ITAINNOVAException, ITAINNOVAExceptionSubmisionFieldNotRequired {
		List<FormInstanceElement> listFormInstances = null;
		Integer index;
		FormElementModel child;
		FormInstanceElementExtension childFormInstanceElementExtension;
		FormInstanceElement childFormInstanceElement;
		List<FormElementModel> listElementModels;

		listElementModels = node.getChildren();
		listFormInstances = new ArrayList<FormInstanceElement>();
		for (index = 0; index < listElementModels.size(); index++) {
			child = listElementModels.get(index);
			childFormInstanceElementExtension = new FormInstanceElementExtension(form, child, submissionUI, listColumns,
					prefix, queryProjection, addInstanceMetadata, cc);
			childFormInstanceElement = new FormInstanceElement(childFormInstanceElementExtension.getName(),
					childFormInstanceElementExtension.getValue());
			listFormInstances.add(childFormInstanceElement);
		}

		return listFormInstances;
	}

	private Object getValueFromSumbission(String name, IForm form, FormElementModel node, SubmissionUI submissionUI,
			List<Column> listColumns, CallingContext cc) throws ITAINNOVAException {
		Object value = null;
		Integer index;
		Boolean found;
		String columnName;
		List<String> values;
		String valueString;
		String fielNameToCompare;
		String correctedName;
		FormInstanceElement formInstanceElement;
		List<FormInstanceElement> listFormInstanceElements;

		if (listColumns == null) {
			throw new ITAINNOVAException("The list of columns could not be null.");
		}
		if (submissionUI == null) {
			throw new ITAINNOVAException("The list of values could not be null.");
		}
		found = false;
		correctedName = name.replace("*", "\\*");
		fielNameToCompare = MATCHING_FIELD_NAME_TEMPLATE.replace(MATCHING_FIELD_NAME_TEMPLATE_TO_REPLACE,
				correctedName);
		index = 0;
		while ((index < listColumns.size()) && (!found)) {
			columnName = listColumns.get(index).getDisplayHeader();
			if (columnName.matches(fielNameToCompare)) {
				found = true;
			} else {
				index++;
			}
		}
		if (!found) {
			throw new ITAINNOVAException("Something was wrong either with the definition of form "
					+ form.getViewableName() + " or with the obtained columns.  Column " + name
					+ " has not be found in the column list.");
		}

		switch (node.getElementType()) {
		case BINARY: // identifies BinaryContent table
		{
			values = submissionUI.getValues();
			value = values.get(index);
			/* 20170206 FJLP because of the performance just return text and put as value the URI of the blob 
			formInstanceElement = this.getBlob((String) value, name, form, node, submissionUI, listColumns, cc );
			listFormInstanceElements = new ArrayList<FormInstanceElement>();
			listFormInstanceElements.add(formInstanceElement);
			value = listFormInstanceElements;
			*/
			break;
		}
		case METADATA:
			// This keeps lint warnings down
			break;
		case GROUP:
			// need to recurse on these elements keeping the same
			// submissionSet...
			throw new ITAINNOVAException("This must not be a Group.");
			/*
			 * groupElements = (List<FormInstanceElement>)
			 * formInstanceElement.getValue(); submitted = submitted &
			 * createFromInstanceElements(topLevelTableKey, iForm,
			 * formElementModel, groupElements, submissionSet,
			 * repeatGroupIndicies, preExisting, cc); break;
			 */
		case REPEAT:
			// Do the same that for a value and then implement a function for
			// obtaining it from the
			// database;
		case STRING:
		case JRDATETIME:
		case JRDATE:
		case JRTIME:
		case INTEGER:
		case DECIMAL:
		case BOOLEAN:
		case GEOTRACE:
		case GEOSHAPE:
		case SELECT1: // identifies SelectChoice table
		case SELECTN: // identifies SelectChoice table
		case GEOPOINT:
		{
			// TODO not considered right now
			values = submissionUI.getValues();
			value = values.get(index);
		}
			break;
		}
		return value;
	}
	
/*   20170206 FJLP saco lo del blob a otro servicio para que vaya m�s r�pido

	private FormInstanceElement getBlob(String valueURI, String name, IForm form, FormElementModel node, SubmissionUI submissionUI,
			List<Column> listColumns, CallingContext cc) throws ITAINNOVAException
	{
		FormInstanceElement formInstanceElement=null;
		byte[] blobValue;
		
		String decodedValueURI;
		String keyString;
		String downloadAsAttachmentString;
		String previewSizeString;
		Boolean previewSize;
		
		SubmissionKey submissionKey;
		String unrootedFileName=null;
		String contentType;
		Long contentLength;
		Date lastUpdateDate;
		List<SubmissionKeyPart> parts;
		Submission submission;
		BlobSubmissionType blobSubmissionType;
		SubmissionElement submissionElement;
		
		try {
			decodedValueURI = java.net.URLDecoder.decode(valueURI, "UTF-8");
		} catch (UnsupportedEncodingException e) {
			throw new ITAINNOVAException(e.getMessage());
		}
		blobValue = null;
	    // verify parameters are present
	    keyString = getBlobInternalURI(decodedValueURI);
	    //TODO review this three assigments
	    downloadAsAttachmentString = null;
	    previewSizeString = null;
	    previewSize = false;
	    if (previewSizeString != null) {
	        previewSize = Boolean.valueOf(previewSizeString);
	    }
	    
	    submissionKey = new SubmissionKey(keyString);
	    parts = submissionKey.splitSubmissionKey();
	    if (parts.get(0).getElementName().equals(PersistentResults.FORM_ID_PERSISTENT_RESULT)) {
	      // special handling for persistent results data...
	      //try {
	      //  PersistentResults p = new PersistentResults(key, cc);
	      //  ResultFileInfo info = p.getResultFileInfo(cc);
	      //  if (info == null) {
	      //    resp.sendError(HttpServletResponse.SC_INTERNAL_SERVER_ERROR,
	      //        "Unable to retrieve attachment");
	      //    return;
	      //  }
	      //  unrootedFileName = info.unrootedFilename;
	     //   contentType = info.contentType;
	      //  contentLength = info.contentLength;
	     //   imageBlob = p.getResultFileContents(cc);
	     //   lastUpdateDate = p.getCompletionDate();
	     // } catch (ODKOverQuotaException e) {
	     //   e.printStackTrace();
	     //   quotaExceededError(resp);
	     //   return;
	     // } catch (ODKDatastoreException e) {
	     //   e.printStackTrace();
	     //   resp.sendError(HttpServletResponse.SC_INTERNAL_SERVER_ERROR,
	     //       "Unable to retrieve attachment");
	     //   return;
	     // }

	    } 
	    else 
	    {
	      try {
	        submission = Submission.fetchSubmission(parts, cc);
	      } catch (ODKFormNotFoundException e1) {
	    	  throw new ITAINNOVAException(e1.getMessage());
	      } catch (ODKOverQuotaException e) {
	    	  throw new ITAINNOVAException(e.getMessage());
	      } catch (ODKDatastoreException e) {
	    	  throw new ITAINNOVAException(e.getMessage());
	      }

	      if (submission != null) 
	      {
	        try 
	        {
	        	submissionElement = submission.resolveSubmissionKey(parts);
	        	if (submissionElement instanceof BlobSubmissionType) 
	        	{
	        		blobSubmissionType = (BlobSubmissionType) submissionElement;
	        	}
	        	else 
	        	{
	        		throw new ITAINNOVAException("Requested object is not a binary one.");
	        	}
	        } 
	        catch (Exception e) 
	        {
	        	throw new ITAINNOVAException(e.getMessage());
	        }

	        try {
	          // ordinal should be 1 if there is just 1 attachment...
	          int ordinal = blobSubmissionType.getAttachmentCount(cc);
	          if ( ordinal != 1 ) {
	            // we have multiple attachments
	            // -- use submissionKey to determine which one we want
	            SubmissionKeyPart p = parts.get(parts.size() - 1);
	            Long ord = p.getOrdinalNumber();
	            if (ord == null) {
	              throw new ITAINNOVAException("Attachment request must be fully qualified.");
	            }
	            // OK. This is the attachment we want...
	            ordinal = ord.intValue();
	          }
	          blobValue = blobSubmissionType.getBlob(ordinal, cc);
	          lastUpdateDate = blobSubmissionType.getLastUpdateDate(ordinal, cc);
	          unrootedFileName = blobSubmissionType.getUnrootedFilename(ordinal, cc);
	          contentType = blobSubmissionType.getContentType(ordinal, cc);
	          contentLength = blobSubmissionType.getContentLength(ordinal, cc);
	        } catch (ODKOverQuotaException e) {
	        	throw new ITAINNOVAException(e.getMessage());
	        } catch (ODKDatastoreException e) {
	        	throw new ITAINNOVAException(e.getMessage());
	        }
	      }
	    }

	    if (blobValue != null && blobValue.length > 0) 
	    {
	    	if ((unrootedFileName!=null) && (unrootedFileName.length()==0))
	    	{
	    		throw new ITAINNOVAException("The name for the binnary content file is not provided for URI:"+decodedValueURI);
	    	}
	    	formInstanceElement = new FormInstanceElement(unrootedFileName, blobValue);
	    } else 
	    {
	    	throw new ITAINNOVAException("Binnary content does not exist or is not accesible usin the provided URI:"+decodedValueURI);
	    }

	    
		return formInstanceElement;
	}
	
	private String getBlobInternalURI(String sevletURI) throws ITAINNOVAException
	{
		String[] splittedString;
		String splittedURI=null;
		
		splittedString = sevletURI.split(BINARY_URI_SEPARATOR);
		if (splittedString.length<2)
		{
			throw new ITAINNOVAException("A non valid value was received in the URI of the binary field:" + sevletURI);
		}
		splittedURI = splittedString[1];
		
		return splittedURI;
	}
*/
}
