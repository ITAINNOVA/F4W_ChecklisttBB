package es.itainnova.f4w.wp6.surveyTaker.data;

public class ServiceRequest {
	
	String userToken;
	

	public ServiceRequest() {
	}

	public ServiceRequest(String userToken) {
		super();
		this.userToken = userToken;
	}


	public String getUserToken() {
		return userToken;
	}

	public void setUserToken(String userToken) {
		this.userToken = userToken;
	}

	

}
