package es.itainnova.f4w.wp6.surveyTaker.data;

public class GetFormInstanceBinnaryServiceRequest extends ServiceRequest {
	
	private String valueURI;
	private String name;
	private String formInstanceID;
	private String formID;

	
	public GetFormInstanceBinnaryServiceRequest() {
		super();
	}


	public GetFormInstanceBinnaryServiceRequest(String valueURI, String name, String formID) {
		super();
		this.valueURI = valueURI;
		this.name = name;
		this.formID = formID;
	}


	public String getValueURI() {
		return valueURI;
	}


	public void setValueURI(String valueURI) {
		this.valueURI = valueURI;
	}


	public String getName() {
		return name;
	}


	public void setName(String name) {
		this.name = name;
	}


	public String getFormID() {
		return formID;
	}


	public void setFormID(String formID) {
		this.formID = formID;
	}


	public String getFormInstanceID() {
		return formInstanceID;
	}


	public void setFormInstanceID(String formInstanceID) {
		this.formInstanceID = formInstanceID;
	}
	

}
