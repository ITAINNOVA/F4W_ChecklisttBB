package es.itainnova.f4w.wp6.surveyTaker.data.odkAccess;

import java.io.IOException;
import java.io.StringReader;
import java.util.List;

import org.javarosa.core.model.FormDef;
import org.javarosa.core.model.instance.TreeElement;
import org.javarosa.xform.parse.XFormParser;
import org.kxml2.kdom.Document;
import org.kxml2.kdom.Element;
import org.opendatakit.aggregate.exception.ODKIncompleteSubmissionData;
import org.opendatakit.aggregate.parser.BaseFormParserForJavaRosa;

import es.itainnova.f4w.wp6.surveyTaker.data.FormElementAttribute;
import es.itainnova.f4w.wp6.surveyTaker.data.FormField;
import es.itainnova.utilities.ITAINNOVAException;

public class ITAINNOVABaseFormParserForJavaRosa extends BaseFormParserForJavaRosa {
	
    private Document xmlDoc;


	public ITAINNOVABaseFormParserForJavaRosa(String existingXml, String existingTitle, boolean allowLegacy)
			throws ODKIncompleteSubmissionData, ITAINNOVAException {
		super(existingXml, existingTitle, allowLegacy);

	    StringReader isr = null;
	      isr = new StringReader(xml);
	      try {
			this.xmlDoc = XFormParser.getXMLDocument(isr);
		} catch (IOException e) {
			throw new ITAINNOVAException(e.getMessage());
		}
		
	}

	public FormDef getFormDef() {
		return this.rootJavaRosaFormDef;
	}

	// TODO FJLP this is due to the fact I don't want to change original ODK
	// source code. A better solutions
	// is need. See the definition of BASE64_RSA_PUBLIC_KEY;
	// ....
	public String getBASE64_RSA_PUBLIC_KEY() {
		String base64RsaPublicKey2 = BASE64_RSA_PUBLIC_KEY;
		return base64RsaPublicKey2;
	}

	@Override
	public List<Element> getBindingsForTreeElement(TreeElement treeElement) {
		// TODO FJLP 20161028 the invoqued method is changed to protected ....
		// review it !!!!
		super.getBindingsForTreeElement(treeElement);

		return super.getBindingsForTreeElement(treeElement);
	}

	public String getNODESET_ATTR() {
		// TODO FJLP 20161028 the invoqued method is changed to protected ....
		// review it !!!!
		return BaseFormParserForJavaRosa.NODESET_ATTR;
	}

	public String getTYPE_ATTR() {
		// TODO FJLP 20161028 the invoqued method is changed to protected ....
		// review it !!!!
		return BaseFormParserForJavaRosa.TYPE_ATTR;
	}

	public String getElementAttributeNameSpace(Element element, int attributeIndex) throws ITAINNOVAException {
		String nameSpace = null;

		if ((attributeIndex < 0) || (attributeIndex> element.getAttributeCount())){
			throw new ITAINNOVAException("It is not possible to find the attribute for the element.");
		}
		nameSpace = element.getAttributeNamespace(attributeIndex);

		return nameSpace;
	}

	public String getElementAttributeName(Element element, int attributeIndex) throws ITAINNOVAException {
		String name = null;

		if ((attributeIndex < 0) || (attributeIndex> element.getAttributeCount())){
			throw new ITAINNOVAException("It is not possible to find the attribute for the element.");
		}
		name= element.getAttributeName(attributeIndex);

		return name;
	}

	public String getElementValue(Element element, int attributeIndex) throws ITAINNOVAException {
		String value = null;

		if ((attributeIndex < 0) || (attributeIndex> element.getAttributeCount())){
			throw new ITAINNOVAException("It is not possible to find the value of the element.");
		}
		
		value= element.getAttributeName(attributeIndex);

		return value;
	}
	
	public FormField getFormField()
	{
		FormField formFieldRoot =null;
		Element rootElement, child;
		int childNumber;
		
		rootElement = this.xmlDoc.getRootElement();
		childNumber =  rootElement.getChildCount();
		child = null;
		
		for (int index=0; index <childNumber; index++)
		{
			child = (Element) rootElement.getChild(index);
			if (child.getName().compareTo("body")==0)
			{
				break;
			}
			else 
			{
				child = null;
			}
		}
		if (child!=null)
		{
			
			formFieldRoot = recursiveGetFormFields(child);
		}
		
		return formFieldRoot;
	}
	
	private FormField recursiveGetFormFields(Element element)
	{
		FormElementAttribute attribute;
		FormField formField, childFormField;
		Object child;
		
		/*formField = new FormField(element.getName(), element.getNamespace(), 
				element.getText(0));*/
		formField = new FormField(element.getName(), element.getNamespace(), 
				"");	
		
		for (int index=0; index<element.getAttributeCount(); index++)
		{
			attribute = new FormElementAttribute(element.getAttributeName(index), 
					element.getAttributeNamespace(index), element.getAttributeValue(index));
			formField.addAttribute(attribute);
		}
		
		for (int index=0; index<element.getChildCount(); index++)
		{
			child =  element.getChild(index);
			if (child instanceof Element) {
				childFormField = recursiveGetFormFields((Element)child);
				formField.addFormField(childFormField);	
			}
			if (child instanceof String) {
				formField.setValue((String)child);
			}
		}
		
		return formField;
	}

}
