package es.itainnova.f4w.wp6.surveyTaker.data;

import java.util.List;

public class FormTranslationText {
	
	public static String ID_NAMESPACE = "";
	public static String ID_NAME= "id";
	
	List <FormElementAttribute> attributes;
	FormValue value;
	

	public FormTranslationText() {
		// TODO Auto-generated constructor stub
	}

	public FormTranslationText(List<FormElementAttribute> attributes, FormValue value) {
		super();
		this.attributes = attributes;
		this.value = value;
	}

	public List<FormElementAttribute> getAttributes() {
		return attributes;
	}


	public void setAttributes(List<FormElementAttribute> attributes) {
		this.attributes = attributes;
	}


	public FormValue getValue() {
		return value;
	}


	public void setValue(FormValue value) {
		this.value = value;
	}

}
