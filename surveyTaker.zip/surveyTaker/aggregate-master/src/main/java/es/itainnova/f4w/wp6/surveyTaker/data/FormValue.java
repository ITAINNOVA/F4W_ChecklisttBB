package es.itainnova.f4w.wp6.surveyTaker.data;

public class FormValue {
	
	public FormValue(String value) {
		super();
		this.value = value;
	}

	String value;

	public FormValue() {
		// TODO Auto-generated constructor stub
	}

	public String getValue() {
		return value;
	}

	public void setValue(String value) {
		this.value = value;
	}

}
