package es.itainnova.f4w.wp6.surveyTaker.data;

public class PostFulfilledFormServiceRequest extends ServiceRequest {
	
	FormInstance formInstance;
	Boolean verbose;
	Boolean readable;
	String openRosaVersion;
	Boolean isMultipart;
	
	public PostFulfilledFormServiceRequest() {
		super();
	}
	public PostFulfilledFormServiceRequest(FormInstance formInstance, Boolean verbose, Boolean readable,
			String openRosaVersion, Boolean isMultipart) {
		super();
		this.formInstance = formInstance;
		this.verbose = verbose;
		this.readable = readable;
		this.openRosaVersion = openRosaVersion;
		this.isMultipart = isMultipart;
	}
	public FormInstance getFormInstance() {
		return formInstance;
	}
	public void setFormInstance(FormInstance formInstance) {
		this.formInstance = formInstance;
	}
	public Boolean getVerbose() {
		return verbose;
	}
	public void setVerbose(Boolean verbose) {
		this.verbose = verbose;
	}
	public Boolean getReadable() {
		return readable;
	}
	public void setReadable(Boolean readable) {
		this.readable = readable;
	}
	public String getOpenRosaVersion() {
		return openRosaVersion;
	}
	public void setOpenRosaVersion(String openRosaVersion) {
		this.openRosaVersion = openRosaVersion;
	}
	public Boolean getIsMultipart() {
		return isMultipart;
	}
	public void setIsMultipart(Boolean isMultipart) {
		this.isMultipart = isMultipart;
	}
	

}
