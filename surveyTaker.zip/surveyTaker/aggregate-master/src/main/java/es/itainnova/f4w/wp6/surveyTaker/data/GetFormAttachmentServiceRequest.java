package es.itainnova.f4w.wp6.surveyTaker.data;

public class GetFormAttachmentServiceRequest extends ServiceRequest {
	
	private String formID;
	private Integer index;
	private Boolean verbose;
	private Boolean readable;
	
	public GetFormAttachmentServiceRequest() {
		super();
	}
	public GetFormAttachmentServiceRequest(String formID, Integer index, Boolean verbose, Boolean readable) {
		super();
		this.formID = formID;
		this.index = index;
		this.verbose = verbose;
		this.readable = readable;
	}
	public String getFormID() {
		return formID;
	}
	public void setFormID(String formID) {
		this.formID = formID;
	}
	public Integer getIndex() {
		return index;
	}
	public void setIndex(Integer index) {
		this.index = index;
	}
	public Boolean getVerbose() {
		return verbose;
	}
	public void setVerbose(Boolean verbose) {
		this.verbose = verbose;
	}
	public Boolean getReadable() {
		return readable;
	}
	public void setReadable(Boolean readable) {
		this.readable = readable;
	}
	

}
