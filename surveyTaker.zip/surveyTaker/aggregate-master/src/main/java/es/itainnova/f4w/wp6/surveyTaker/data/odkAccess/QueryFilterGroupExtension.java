package es.itainnova.f4w.wp6.surveyTaker.data.odkAccess;

import java.util.ArrayList;

import org.opendatakit.aggregate.client.filter.Filter;
import org.opendatakit.aggregate.client.filter.FilterGroup;

import es.itainnova.f4w.wp6.surveyTaker.data.QueryFilterGroup;
import es.itainnova.f4w.wp6.surveyTaker.data.QueryUIResumePoint;
import es.itainnova.f4w.wp6.surveyTaker.data.odkAccess.QueryFilter.ITAINNOVAQueryFilterBooleanOperation;

public class QueryFilterGroupExtension extends QueryFilterGroup {
	
	public QueryFilterGroupExtension() {
		super();
	}

	QueryFilterGroupExtension(String uri, String name, String formId, ITAINNOVAQueryFilterBooleanOperation filters, Boolean includeMetadata,
			int queryFetchLimit, QueryUIResumePoint cursor)
	{
		super(uri, name, formId, filters, includeMetadata, queryFetchLimit, cursor);
	}
	
	public FilterGroup convertQueryFilterGroupToODKFilterGroup()
	{
		FilterGroup filterGroup;
		
		//20170209 Not clear how to use this filter an apply filter functions should have to be implemented
		ArrayList<Filter> filtersToApply=null;
		
		filterGroup = new FilterGroup(this.getName(), this.getFormId(),filtersToApply);
		filterGroup.setIncludeMetadata(this.getIncludeMetadata());
		return filterGroup;
	}
}
