package es.itainnova.f4w.wp6.surveyTaker.data.odkAccess.QueryFilter;

import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;

import es.itainnova.f4w.wp6.surveyTaker.data.FormInstanceElement;
import es.itainnova.utilities.ITAINNOVAException;

public class ITAINNOVAQueryFilterBinnaryComparisonOperation implements ITAINNOVAQueryFilterTrueValueInterface {

	private static String INTEGER_REGEX = "[-+]?([0-9]*";
	private static String FLOAT_REGEX = "[-+]?([0-9]*\\.[0-9]+|[0-9]+)";
	private static String BOOLEAN_REGEX = "true|false";
	private static String DATE_REGEX = "";

	private static String ARGUMENT1_JSON_STRING = "argument1";
	private static String ARGUMENT2_JSON_STRING = "argument2";
	private static String OPERATOR_JSON_STRING = "operator";

	Object argument1;
	Object argument2;
	ITAINNOVAQueryFilterBinnaryComparisonOperators operator;

	public ITAINNOVAQueryFilterBinnaryComparisonOperation() {
		super();
	}

	public ITAINNOVAQueryFilterBinnaryComparisonOperation(Object argument1, Object argument2,
			ITAINNOVAQueryFilterBinnaryComparisonOperators operator) {
		//super();
		this.argument1 = argument1;
		this.argument2 = argument2;
		this.operator = operator;
	}

	public Object getArgument1() {
		return argument1;
	}

	public void setArgument1(Object argument1) {
		this.argument1 = argument1;
	}

	public Object getArgument2() {
		return argument2;
	}

	public void setArgument2(Object argument2) {
		this.argument2 = argument2;
	}

	public ITAINNOVAQueryFilterBinnaryComparisonOperators getOperator() {
		return operator;
	}

	public void setOperator(ITAINNOVAQueryFilterBinnaryComparisonOperators operator) {
		this.operator = operator;
	}

	public Boolean evaluateTrueValue() throws ITAINNOVAException {
		Boolean trueValue = false;

		trueValue = this.evaluateTrueValue(false);

		return trueValue;
	}

	public Boolean evaluateTrueValue(Boolean considerUnderlyingClass) throws ITAINNOVAException

	{
		Boolean trueValue = false;

		if ((this.argument1 == null) || (this.argument2 == null)) {
			throw new ITAINNOVAException(this.getClass().getCanonicalName() + " requires two not null arguments");
		}
		switch (this.operator) {
		case EQUAL: {
			trueValue = this.argument1.equals(this.argument2);
			break;
		}
		case DISTINTC: {
			trueValue = !this.argument1.equals(this.argument2);
			break;
		}
		case GREATER:
		case SMALLER:
		case GREATEROREQUAL:
		case SMALLEROREQUAL: {
			if (!considerUnderlyingClass) {

			} else {
				throw new ITAINNOVAException(
						this.toString() + " operation is not currently implemented considering argument types");
			}
			break;
		}
		case CONTAINS: {
			if (!considerUnderlyingClass) {
				trueValue = this.argument1ToString().contains(this.argument2ToString());

			} else {
				throw new ITAINNOVAException(
						"CONTAINS operation is not currently implemented considering argument types");
			}
			break;
		}
		default: {
			throw new ITAINNOVAException("The operator:" + this.operator.getStringRepresentation()
					+ " is not implemented by the current version of " + this.getClass().getCanonicalName() + ".");
		}
		}
		return trueValue;
	}
	private String argumentToString(Object argument)
	{
		String returnedString=null;
		if (argument instanceof String)
		{
			returnedString = (String)argument;
		}
		else
		{
			returnedString = argument1.toString();
		}
		return returnedString;
	}
	private String argument1ToString()
	{
		return this.argumentToString(this.argument1);
	}
	private String argument2ToString()
	{
		return this.argumentToString(this.argument2);
	}


	@Override
	public List<String> extractArguments() {
		List<String> arguments;

		arguments = new ArrayList<String>();
		if (this.getArgument1() != null)
			arguments.add(this.getArgument1().toString());
		if (this.getArgument2() != null)
			arguments.add(this.getArgument2().toString());
		return null;
	}

	public static Boolean isITAINNOVAQueryFilterBinnaryComparisonOperation(LinkedHashMap<String, Object> linkedHashMap)
			throws ITAINNOVAException {
		Boolean isRequiredType = true;
		Object valueObject;

		if (linkedHashMap == null) {
			throw new ITAINNOVAException("Null can not be converted to a Binnary Comparison Operation");
		}

		for (String key : linkedHashMap.keySet()) {
			if (!((key.equals(ARGUMENT1_JSON_STRING) || key.equals(ARGUMENT2_JSON_STRING)
					|| key.equals(OPERATOR_JSON_STRING)))) {
				throw new ITAINNOVAException("The argument field names does not match the supported one by the"
						+ " current version of ITAINNOVAQueryFilterBinnaryComparisonOperation.");
			}
			valueObject = linkedHashMap.get(key);
			if (valueObject!=null)
			{
				if (!((valueObject instanceof String) || (valueObject instanceof LinkedHashMap<?,?>)))
				{
					throw new ITAINNOVAException("The class of the value:" + valueObject.getClass()+
							" is not supported by the current version of ITAINNOVAQueryFilterBinnaryComparisonOperation.");
				}
			}
		}
		return isRequiredType;

	}

	public static ITAINNOVAQueryFilterBinnaryComparisonOperation convertJSONtoTAINNOVAQueryFilterBinnaryComparisonOperation(
			LinkedHashMap<String, Object> linkedHashMap) throws ITAINNOVAException {
		ITAINNOVAQueryFilterBinnaryComparisonOperation value = null;
		Object valueObject;
		Object argument1=null, argument2=null, operator=null;

		if (linkedHashMap != null) {
			for (String key : linkedHashMap.keySet()) {
				valueObject = linkedHashMap.get(key);
				if (key.equals(ARGUMENT1_JSON_STRING))
				{
					argument1 = ITAINNOVAQueryFilterBinnaryComparisonOperation.getJSONFieldValue(key, valueObject);
				}
				else if( key.equals(ARGUMENT2_JSON_STRING))
				{
					argument2 = ITAINNOVAQueryFilterBinnaryComparisonOperation.getJSONFieldValue(key, valueObject);
				}
				else if( key.equals(OPERATOR_JSON_STRING))
				{
					operator = ITAINNOVAQueryFilterBinnaryComparisonOperation.getJSONFieldValue(key, valueObject);
				}
				else
				{
					throw new ITAINNOVAException("The argument field names does not match the supported one by the"
							+ " current version of ITAINNOVAQueryFilterBinnaryComparisonOperation.");
				}
			}
			value = new ITAINNOVAQueryFilterBinnaryComparisonOperation(argument1, argument2,
					(ITAINNOVAQueryFilterBinnaryComparisonOperators)operator);
		}

		return value;

	}

	private static Object getJSONFieldValue(String argumentKey, Object argumentValue) throws ITAINNOVAException {
		Object value = null;
		
		if (argumentKey.equals(ARGUMENT1_JSON_STRING) ||( argumentKey.equals(ARGUMENT2_JSON_STRING)))
		{
			if (argumentValue instanceof String)
			{
				value = argumentValue;
			}
			else
			{
				//TODO recursive binnary comparison operation arguments.
				throw new ITAINNOVAException("Recursive binnary opeation arguments are not yet implemented by "
						+ " current version of ITAINNOVAQueryFilterBinnaryComparisonOperation.");
			}
		}
		else if( argumentKey.equals(OPERATOR_JSON_STRING))
		{
			if (argumentValue instanceof String)
			{
				value = ITAINNOVAQueryFilterBinnaryComparisonOperators.
						giveMeBinnaryComparisonOperatorFromJSONrepresentation( (String)argumentValue);
			}
			else
			{
				throw new ITAINNOVAException("Just an String can be used for represent a Binnary operation in JSON");
			}
		}
		

		return value;
	}
	
	@Override
	protected ITAINNOVAQueryFilterBinnaryComparisonOperation clone() {
		ITAINNOVAQueryFilterBinnaryComparisonOperation clonedItainnovaQueryFilterBinnaryComparisonOperation = null;
		Object clonedArgument1;
		Object clonedArgument2;
		Object clonedOperator;
		
		try {
			clonedArgument1 = this.cloneArgument(this.getArgument1());
			clonedArgument2 = this.cloneArgument(this.getArgument2());
		} catch (ITAINNOVAException e) {
			clonedArgument1 = null;
			clonedArgument2 = null;
		}
		clonedOperator = this.cloneOperator(this.getOperator());

		clonedItainnovaQueryFilterBinnaryComparisonOperation = new ITAINNOVAQueryFilterBinnaryComparisonOperation(
				clonedArgument1, clonedArgument2, (ITAINNOVAQueryFilterBinnaryComparisonOperators)clonedOperator);

		return clonedItainnovaQueryFilterBinnaryComparisonOperation;
	}

	private Object cloneArgument(Object argument) throws ITAINNOVAException {
		Object cloned = null;
		
		if (argument instanceof String )
		{
			cloned = new String((String)argument);
		}
		else
		{
			throw new ITAINNOVAException("Recursive Binnary Comparison Operations are not yet implemented.");
		}
		return cloned;
	}

	private Object cloneOperator(Object operator) {
		return operator;
	}

	public Object replaceColumnNameByValue(String key, String value) throws ITAINNOVAException {
		
		this.setArgument1(this.replaceColumnNameByValueArgument(this.getArgument1(), key, value));
		this.setArgument2(this.replaceColumnNameByValueArgument(this.getArgument2(), key, value));
		
		return this;

	}

	private String replaceColumnNameByValueArgument(Object argument, String key, String value) throws ITAINNOVAException {
		
		if (argument instanceof String)
		{
			if (value == null)
			{
				return ((String)argument).replace(key, "null");
			}
			else
			{
				return ((String)argument).replace(key, value);
			}
		}
		else if (argument instanceof ITAINNOVAQueryFilterBinnaryComparisonOperation)
		{
			//TODO recursive definition of Binnary Comparison Operation
			throw new ITAINNOVAException("Recursive Binnary Comparison Operations are not yet implemented.");
		}
		else 
		{
			//TODO recursive definition of Binnary Comparison Operation
			throw new ITAINNOVAException("Recursive Binnary Comparison Operations are not yet implemented.");
		}
	}

}
