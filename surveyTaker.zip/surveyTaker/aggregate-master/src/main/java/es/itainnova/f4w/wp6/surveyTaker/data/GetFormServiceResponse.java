package es.itainnova.f4w.wp6.surveyTaker.data;

public class GetFormServiceResponse extends ServiceResponse {
	
	Form form;

	public GetFormServiceResponse() {
		super();
	}

	public GetFormServiceResponse(Form form) {
		super();
		this.form = form;
	}

	public Form getForm() {
		return form;
	}

	public void setForm(Form form) {
		// TODO remove it when XML will be required.
		form.setXml(null);
		this.form = form;
	}

}
