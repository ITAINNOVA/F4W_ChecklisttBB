package es.itainnova.f4w.wp6.surveyTaker.data;


public class ListFormsServiceResponse extends ServiceResponse {
	
	FormList formList;

	public ListFormsServiceResponse() {
	}

	public ListFormsServiceResponse(String userToken, FormList formList) {
		super(userToken);
		this.formList = formList;
	}

	public String getUserToken() {
		return userToken;
	}

	public void setUserToken(String userToken) {
		this.userToken = userToken;
	}

	public FormList getFormList() {
		return formList;
	}

	public void setFormList(FormList formList) {
		this.formList = formList;
	}
	
	
	public void addForm(Form form)
	{
		if (this.formList  == null)
		{
			formList= new FormList();
		}
		formList.addForm(form);
	}
	
	public void createTestListForm(String userToken)
	{
		Form f1 = new Form("1");
		Form f2 = new Form("2");
		Form f3 = new Form("3");
		Form f4 = new Form("4");
		
		this.setUserToken(userToken);
		
		this.formList = new FormList();
		this.formList.addForm(f1);
		this.formList.addForm(f2);
		this.formList.addForm(f2);
		this.formList.addForm(f4);
	}
	

}
