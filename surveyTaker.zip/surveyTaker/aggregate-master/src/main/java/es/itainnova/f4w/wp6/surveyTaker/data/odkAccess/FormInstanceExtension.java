package es.itainnova.f4w.wp6.surveyTaker.data.odkAccess;

import java.util.List;

import javax.servlet.http.HttpServletRequest;

import org.opendatakit.aggregate.ContextFactory;
import org.opendatakit.aggregate.client.exception.FormNotAvailableException;
import org.opendatakit.aggregate.client.exception.RequestFailureException;
import org.opendatakit.aggregate.client.submission.Column;
import org.opendatakit.aggregate.client.submission.SubmissionUI;
import org.opendatakit.aggregate.client.submission.SubmissionUISummary;
import org.opendatakit.aggregate.constants.ErrorConsts;
import org.opendatakit.aggregate.datamodel.FormElementModel;
import org.opendatakit.aggregate.datamodel.FormElementModel.ElementType;
import org.opendatakit.aggregate.exception.ODKFormNotFoundException;
import org.opendatakit.aggregate.form.FormFactory;
import org.opendatakit.aggregate.form.IForm;
import org.opendatakit.aggregate.format.Row;
import org.opendatakit.aggregate.format.element.ElementFormatter;
import org.opendatakit.aggregate.format.element.UiElementFormatter;
import org.opendatakit.aggregate.server.GenerateHeaderInfo;
import org.opendatakit.aggregate.submission.Submission;
import org.opendatakit.aggregate.submission.SubmissionElement;
import org.opendatakit.aggregate.submission.SubmissionKey;
import org.opendatakit.aggregate.submission.SubmissionKeyPart;
import org.opendatakit.aggregate.submission.SubmissionSet;
import org.opendatakit.aggregate.submission.type.RepeatSubmissionType;
import org.opendatakit.common.persistence.client.exception.DatastoreFailureException;
import org.opendatakit.common.persistence.exception.ODKDatastoreException;
import org.opendatakit.common.persistence.exception.ODKOverQuotaException;
import org.opendatakit.common.security.client.exception.AccessDeniedException;
import org.opendatakit.common.web.CallingContext;

import es.itainnova.f4w.wp6.surveyTaker.data.FormInstance;
import es.itainnova.f4w.wp6.surveyTaker.data.FormInstanceElement;
import es.itainnova.f4w.wp6.surveyTaker.data.QueryProjection;
import es.itainnova.utilities.ITAINNOVAException;
import es.itainnova.utilities.ITAINNOVAExceptionSubmisionFieldNotRequired;

public class FormInstanceExtension extends FormInstance {

	public FormInstanceExtension() {
		super();
	}

	public FormInstanceExtension(FormInstance formInstance) {
		super();

		this.setAttributes(formInstance.getAttributes());
		this.setElements(formInstance.getElements());
	}

	public FormInstanceExtension(IForm form, SubmissionUI submissionUI, List<Column> listColumns,
			QueryProjection queryProjection, Boolean addMetadata, CallingContext cc) throws ITAINNOVAException {
		FormElementModel iFormDataModel;

		iFormDataModel = form.getTopLevelGroupElement();

		this.createFormInstanceAttributes(form, iFormDataModel);
		this.createFromInstance(form, iFormDataModel, submissionUI, listColumns, queryProjection, addMetadata, cc);
		
		if (addMetadata)
		{
			this.createFormMetada(form, iFormDataModel, submissionUI, listColumns, cc);
		}
	}

	public String getInstanceName() throws ITAINNOVAException {
		String instanceName;
		instanceName = ((FormInstanceElement) this.getAttributeByName(INSTANCE_NAME_KEY)).readStringValue();

		return instanceName;
	}

	public String getFormID() throws ITAINNOVAException {
		String formID;
		formID = this.getAttributeByName(FORM_ID_KEY).readStringValue();

		return formID;
	}

	public String getVersion() throws ITAINNOVAException {
		String version;
		version = this.getAttributeByName(VERSION_KEY).readStringValue();

		return version;
	}

	public String getUiVersion() throws ITAINNOVAException {
		String uiVersion;
		uiVersion = this.attributeStringValue(VERSION_UI_KEY);

		return uiVersion;
	}

	public String getSubmisionDate() throws ITAINNOVAException {
		String submissionDate;

		submissionDate = this.attributeStringValue(SUBMISSION_DATE_KEY);

		return submissionDate;
	}

	public String getMarkedAsCompletedDate() throws ITAINNOVAException {
		String markedAsCompletedDate;

		markedAsCompletedDate = this.attributeStringValue(MARKED_AS_COMPLETED_DATE_KEY);

		return markedAsCompletedDate;
	}

	private String attributeStringValue(String name) throws ITAINNOVAException {
		String stringValue = null;

		stringValue = this.elementStringValue(name, this.getAttributes());

		return stringValue;
	}

	private String elementStringValue(String name, List<FormInstanceElement> formInstanceElements)
			throws ITAINNOVAException {
		String stringValue = null;
		FormInstanceElement formInstanceElement;

		if ((name != null) && (name.length() > 0)) {
			if (formInstanceElements != null) {
				formInstanceElement = this.getElementByNameFromList(name, formInstanceElements);
				if (formInstanceElement != null) {
					stringValue = formInstanceElement.readStringValue();
				}
			}
		}
		return stringValue;

	}

	public FormInstanceElement getMeta() {
		FormInstanceElement formInstanceElement;
		formInstanceElement = this.getElementByNameFromList(META_KEY, this.getElements());
		return formInstanceElement;
	}

	public void setMeta(List<FormInstanceElement> formInstanceMetaElements) throws ITAINNOVAException {
		this.addElement(new FormInstanceElement(META_KEY, formInstanceMetaElements));
	}

	@SuppressWarnings("unchecked")
	public String getInstanceID() throws ITAINNOVAException {
		String instanceID = null;
		FormInstanceElement meta;
		List<FormInstanceElement> formInstanceElements = null;
		FormInstanceElement formInstanceElement;

		meta = (FormInstanceElement) this.getMeta();
		formInstanceElements = (List<FormInstanceElement>) meta.getValue();
		if ((formInstanceElements != null) && (formInstanceElements.size() > 0)) {
			formInstanceElement = (FormInstanceElement) this.getElementByNameFromList(INSTANCE_ID_KEY,
					formInstanceElements);
			if (formInstanceElement != null) {
				instanceID = (String) formInstanceElement.getValue();
			}
		}

		return instanceID;
	}

	@SuppressWarnings("unchecked")
	public void setInstanceID(String instanceID) throws ITAINNOVAException {
		FormInstanceElement meta;
		List<FormInstanceElement> formInstanceElements = null;
		FormInstanceElement formInstanceElement;

		meta = (FormInstanceElement) this.getMeta();
		if (meta != null) {
			formInstanceElements = (List<FormInstanceElement>) meta.getValue();
			if ((formInstanceElements != null) && (formInstanceElements.size() > 0)) {
				formInstanceElement = (FormInstanceElement) this.getElementByNameFromList(INSTANCE_ID_KEY,
						formInstanceElements);
				if (formInstanceElement != null) {
					formInstanceElement.setValue(instanceID);
				}
			}
		}

	}

	private void createFormInstanceAttributes(IForm form, FormElementModel node) {
		try {
			this.addAttribute(new FormInstanceElement(INSTANCE_NAME_KEY, node.getElementName()));
			this.addAttribute(new FormInstanceElement(FORM_ID_KEY, form.getFormId()));
			// TODO check how to obtain this values
			this.addAttribute(new FormInstanceElement(VERSION_KEY, null));
		} catch (ITAINNOVAException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	private void createFromInstance(IForm form, FormElementModel node, SubmissionUI submissionUI,
			List<Column> listColumns, QueryProjection queryProjection, Boolean addInstanceMetadata, CallingContext cc) throws ITAINNOVAException {
		List<FormElementModel> listElementModels;
		FormElementModel child;
		Integer index;
		FormInstanceElementExtension childFormInstanceElementExtension;
		FormInstanceElement childFormInstanceElement;

		if (node == null) {
			throw new ITAINNOVAException(
					"Something wrong happens with the definition of the Form:" + form.getViewableName());
		}
		listElementModels = node.getChildren();
		if (listElementModels != null) {
			for (index = 0; index < listElementModels.size(); index++) {
				child = listElementModels.get(index);
					//Initially the prefix is none
					try {
						childFormInstanceElementExtension = new FormInstanceElementExtension(form, child, submissionUI, listColumns, 
								"", queryProjection, addInstanceMetadata, cc);
						childFormInstanceElement = new FormInstanceElement(childFormInstanceElementExtension.getName(), 
								childFormInstanceElementExtension.getValue());
						this.addElement(childFormInstanceElement);
					} catch (ITAINNOVAExceptionSubmisionFieldNotRequired e) {
						// Do nothing it is an element which have no to be added here
						continue;
					}
					catch (ITAINNOVAException e) {
						// TODO Auto-generated catch block
						throw e;
					}

			}
		}

	}

	private Boolean addNodeToResult(FormElementModel node, QueryProjection queryProjection) {
		Boolean add = true;
		List<String> fields;
		Integer index;
		String fieldToConsider;
		String nodeName;

		nodeName = node.getElementName();
		if (nodeName.matches("^\\*meta.*\\*$")) {
			add = false;
		}
		if (queryProjection != null) {
			fields = queryProjection.getProjectionFields();
			if ((fields != null)) 
			{
				add = false;
				for (index = 0; ((index < fields.size()) && (!add)); index++) {
					fieldToConsider = fields.get(index);
					if (nodeName.equals(fieldToConsider)) {
						add = true;
					}
				}
			}
		}

		return add;
	}


	private void createFormMetada(IForm form, FormElementModel node, SubmissionUI submissionUI,
			List<Column> listColumns,  CallingContext cc) throws ITAINNOVAException {
		List<FormElementModel> listElementModels;
		FormElementModel child;
		Integer index;
		FormInstanceElementExtension childFormInstanceElementExtension;
		FormInstanceElement childFormInstanceElement;

		if (node == null) {
			throw new ITAINNOVAException(
					"Something wrong happens with the definition of the Form:" + form.getViewableName());
		}
		listElementModels = node.getChildren();
		if (listElementModels != null) {
			for (index = 0; index < listElementModels.size(); index++) {
				child = listElementModels.get(index);
				if (addNodeToMetadata(child)) {
					childFormInstanceElementExtension = new FormInstanceElementExtension(form, child, submissionUI, listColumns, cc);
					childFormInstanceElement = new FormInstanceElement(childFormInstanceElementExtension.getName(), 
							childFormInstanceElementExtension.getValue());
					this.addMetaElement(childFormInstanceElement);
				}

			}
		}

	}

	private Boolean addNodeToMetadata(FormElementModel node) {
		Boolean add = true;
		List<String> fields;
		Integer index;
		String fieldToConsider;
		String nodeName;

		nodeName = node.getElementName();
		if (nodeName.matches("^\\*meta.*\\*$")) {
			add = true;
		}
		else {
			add = false;
		}

		return add;
	}

	
	private void createFormRepeats(IForm form, FormElementModel node, SubmissionUI submissionUI,
			List<Column> listColumns)
	{
		
	}
	
/*	  public SubmissionUISummary getRepeatSubmissions(String keyString)
		      throws FormNotAvailableException, RequestFailureException, DatastoreFailureException,
		      AccessDeniedException {
		    HttpServletRequest req = this.getThreadLocalRequest();
		    CallingContext cc = ContextFactory.getCallingContext(this, req);

		    if (keyString == null) {
		      return null;
		    }

		    try {
		      SubmissionKey key = new SubmissionKey(keyString);
		      List<SubmissionKeyPart> parts = key.splitSubmissionKey();
		      IForm form = FormFactory.retrieveFormByFormId(parts.get(0).getElementName(), cc);
		      if (!form.hasValidFormDefinition()) {
		        throw new RequestFailureException(ErrorConsts.FORM_DEFINITION_INVALID); // ill-formed
		                                                                                // definition
		      }
		      Submission sub = Submission.fetchSubmission(parts, cc);

		      if (sub != null) {
		        SubmissionElement tmp = sub.resolveSubmissionKey(parts);
		        RepeatSubmissionType repeat = (RepeatSubmissionType) tmp;

		        SubmissionUISummary summary = new SubmissionUISummary(form.getViewableName());
		        GenerateHeaderInfo headerGenerator = new GenerateHeaderInfo(null, summary, form);
		        headerGenerator.processForHeaderInfo(repeat.getElement());
		        List<FormElementModel> filteredElements = headerGenerator.getIncludedElements();
		        ElementFormatter elemFormatter = new UiElementFormatter(cc.getServerURL(),
		            headerGenerator.getGeopointIncludes());

		        // format row elements
		        for (SubmissionSet subSet : repeat.getSubmissionSets()) {
		          Row row = subSet.getFormattedValuesAsRow(filteredElements, elemFormatter, false, cc);
		          try {
		            summary.addSubmission(new SubmissionUI(row.getFormattedValues(), null));
		          } catch (Exception e) {
		            e.printStackTrace();
		          }
		        }
		        return summary;

		      } else {
		        return null;
		      }

		    } catch (ODKFormNotFoundException e) {
		      e.printStackTrace();
		      throw new FormNotAvailableException(e);
		    } catch (ODKOverQuotaException e) {
		      e.printStackTrace();
		      throw new RequestFailureException(ErrorConsts.QUOTA_EXCEEDED);
		    } catch (ODKDatastoreException e) {
		      e.printStackTrace();
		      throw new DatastoreFailureException(e);
		    }
		  }
*/
}
