package es.itainnova.f4w.wp6.surveyTaker.data.odkAccess.QueryFilter;

import java.util.ArrayList;
import java.util.List;

import es.itainnova.utilities.ITAINNOVAException;

public enum ITAINNOVAQueryFilterBooleanValue implements ITAINNOVAQueryFilterTrueValueInterface {
	TRUE("true"),
	FALSE("false");
	
	String stringRepresentation;
	ITAINNOVAQueryFilterBooleanValue()
	{
		
	}
	
	ITAINNOVAQueryFilterBooleanValue (String stringRepresentation)
	{
		this.stringRepresentation =stringRepresentation;
	}
	
	public String getStringRepresentation() {
		return stringRepresentation;
	}

	public void setStringRepresentation(String stringRepresentation) {
		this.stringRepresentation = stringRepresentation;
	}

	@Override
	public Boolean evaluateTrueValue() throws ITAINNOVAException {
		
		return this.evaluateTrueValue(false);
	}

	@Override
	public Boolean evaluateTrueValue(Boolean considerUnderlyingClass) throws ITAINNOVAException {
		Boolean trueValue=false;
		
		trueValue = new Boolean(this.getStringRepresentation());
		
		return trueValue;
	}

	@Override
	public List<String> extractArguments() {
		
		List<String> arguments;
		
		arguments = new ArrayList<String>();
		
		arguments.add(this.stringRepresentation);
		// TODO Auto-generated method stub
		return arguments;
	}

	public static ITAINNOVAQueryFilterBooleanValue giveMeTheBooleanTypeValue(Object argument) throws ITAINNOVAException
	{
		ITAINNOVAQueryFilterBooleanValue returnedValue=null;
		String argumentString;
		
		if (argument instanceof String)
		{
			argumentString= ((String)argument).toLowerCase();
			if (ITAINNOVAQueryFilterBooleanValue.FALSE.getStringRepresentation().endsWith(argumentString))
			{
				returnedValue = ITAINNOVAQueryFilterBooleanValue.FALSE;
			}
			if (ITAINNOVAQueryFilterBooleanValue.TRUE.getStringRepresentation().endsWith(argumentString))
			{
				returnedValue = ITAINNOVAQueryFilterBooleanValue.TRUE;
			}
			if (returnedValue==null)
			{
				throw new ITAINNOVAException("The given argument: "+ 
						argumentString+ " can not be converted to a value of class: "+ ITAINNOVAQueryFilterBooleanValue.class.getCanonicalName() );
			}
		}
		else
		{
			throw new ITAINNOVAException("The given argument class: "+ 
		       argument.getClass().getCanonicalName()+ " can not be converted to: "+ ITAINNOVAQueryFilterBooleanValue.class.getCanonicalName() );
		}
		return returnedValue;
	}

}
