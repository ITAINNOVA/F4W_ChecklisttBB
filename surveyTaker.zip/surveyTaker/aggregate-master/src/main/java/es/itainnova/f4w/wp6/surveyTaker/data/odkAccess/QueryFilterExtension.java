package es.itainnova.f4w.wp6.surveyTaker.data.odkAccess;

import org.opendatakit.aggregate.client.filter.Filter;
import org.opendatakit.aggregate.constants.common.Visibility;
import org.opendatakit.aggregate.constants.common.RowOrCol;
import es.itainnova.f4w.wp6.surveyTaker.data.QueryFilter;


public class QueryFilterExtension extends QueryFilter {

	public QueryFilterExtension() {
		super();
	}

	public QueryFilterExtension(String uri, Long ordinal) {
		super(uri, ordinal);
	}
	
	public Filter convertQueryFilterToODKFilter()
	{
		Filter filter=null;

		
		//TODO review it when filters are needed !!!!
//		filter = new FilterSet(Visibility.DISPLAY,RowOrCol.ROW, this.getOrdinal());
		
		return filter;
	}
}
