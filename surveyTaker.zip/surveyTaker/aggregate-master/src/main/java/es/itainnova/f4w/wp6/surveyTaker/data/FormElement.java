package es.itainnova.f4w.wp6.surveyTaker.data;

import java.util.ArrayList;
import java.util.List;



import es.itainnova.utilities.ITAINNOVAException;

public class FormElement {
	

	/*
	 * Element name
	 */
	private String name;
	private String nameSpace;
	/**
	 * It is use when multi-language labels are specified.  It is the identifier of the label in a given language.  See FormLocalizer for details.
	 */
	private String textID;
	/**
	 * It is used when just one language is use for labeling shown form fields.
	 */
	private String defaultText;
	private String value;
	private List <FormElementAttribute> attributes;
	private List <FormElementBinding> bindings;
	private List <FormElement>  children;

	public FormElement() {
		super();
	}

	public FormElement(String name, String prefix, String value) {
		super();
		this.name = name;
		this.nameSpace = prefix;
		this.attributes = new ArrayList<FormElementAttribute>();
		this.bindings = new ArrayList<FormElementBinding>();
		this.children = new ArrayList<FormElement>();
		this.value = value;
	}

	public FormElement(String name) {
		super();
		this.name = name;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getNameSpace() {
		return nameSpace;
	}

	public void setNameSpace(String nameSpace) {
		this.nameSpace = nameSpace;
	}

	public String getTextID() {
		return textID;
	}

	public void setTextID(String textID) {
		this.textID = textID;
	}

	/**
	 * @return the defaultText
	 */
	public String getDefaultText() {
		return defaultText;
	}

	/**
	 * @param defaultText the defaultText to set
	 */
	public void setDefaultText(String defaultText) {
		this.defaultText = defaultText;
	}

	public String getValue() {
		return value;
	}

	public void setValue(String value) {
		this.value = value;
	}

	public List<FormElementAttribute> getAttributes() {
		return attributes;
	}

	public void setAttributes(List<FormElementAttribute> attributes) {
		this.attributes = attributes;
	}
	
	
	
	public List<FormElementBinding> getBindings() {
		return bindings;
	}

	public void setBindings(List<FormElementBinding> bindings) {
		this.bindings = bindings;
	}

	public List<FormElement> getChildren() {
		return children;
	}

	public void setChildren(List<FormElement> children) {
		this.children = children;
	}

	public void addAtribute(FormElementAttribute attribute) throws ITAINNOVAException
	{
		if (this.attributes!=null)
		{
			this.attributes.add(attribute);
		}
		else
		{
			throw new ITAINNOVAException("FormElement has not been correctly initialized");
		}
	}

	public void addBingind(FormElementBinding binding) throws ITAINNOVAException
	{
		if (this.bindings!=null)
		{
			this.bindings.add(binding);
		}
		else
		{
			throw new ITAINNOVAException("FormElement has not been correctly initialized");
		}
	}
	
	public void addChild(FormElement formElement) throws ITAINNOVAException
	{
		if (this.children!=null)
		{
			this.children.add(formElement);
		}
		else
		{
			throw new ITAINNOVAException("FormElement has not been correctly initialized");
		}
		
	}

}
