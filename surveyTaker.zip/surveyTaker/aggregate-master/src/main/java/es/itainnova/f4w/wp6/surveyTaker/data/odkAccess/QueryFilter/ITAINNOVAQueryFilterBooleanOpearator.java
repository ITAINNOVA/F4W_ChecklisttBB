package es.itainnova.f4w.wp6.surveyTaker.data.odkAccess.QueryFilter;

public enum ITAINNOVAQueryFilterBooleanOpearator {

	NOT("not"), AND("AND"), OR("OR");

	String stringRepresentation;

	ITAINNOVAQueryFilterBooleanOpearator() {

	}

	ITAINNOVAQueryFilterBooleanOpearator(String stringRepresentation) {
		this.stringRepresentation = stringRepresentation;
	}

	public String getStringRepresentation() {
		return stringRepresentation;
	}

	public void setStringRepresentation(String stringRepresentation) {
		this.stringRepresentation = stringRepresentation;
	}

	public static ITAINNOVAQueryFilterBooleanOpearator giveMeBooleanOperatorFromJSONrepresentation(
			String jsonRepresentation) {
		ITAINNOVAQueryFilterBooleanOpearator operator = null;

		if (jsonRepresentation.equals(ITAINNOVAQueryFilterBooleanOpearator.NOT.stringRepresentation)) {
			operator = ITAINNOVAQueryFilterBooleanOpearator.NOT;
		}
		if (jsonRepresentation.equals(ITAINNOVAQueryFilterBooleanOpearator.AND.stringRepresentation)) {
			operator = ITAINNOVAQueryFilterBooleanOpearator.AND;
		}
		if (jsonRepresentation.equals(ITAINNOVAQueryFilterBooleanOpearator.OR.stringRepresentation)) {
			operator = ITAINNOVAQueryFilterBooleanOpearator.OR;
		}

		return operator;
	}
	

}
