package es.itainnova.f4w.wp6.surveyTaker.data;

import es.itainnova.f4w.wp6.surveyTaker.data.odkAccess.QueryFilter.ITAINNOVAQueryFilterBooleanOperation;

public class QueryFilterGroup {

	private String uri; // unique identifier
	private String name;
	private String formId;
	private ITAINNOVAQueryFilterBooleanOperation queryFilter;

	private Boolean includeMetadata;

	private int queryFetchLimit;

	private QueryUIResumePoint cursor;

	public QueryFilterGroup() {
		super();
	}

	public QueryFilterGroup(String uri, String name, String formId, ITAINNOVAQueryFilterBooleanOperation queryFilter, Boolean includeMetadata,
			int queryFetchLimit, QueryUIResumePoint cursor) {
		super();
		this.uri = uri;
		this.name = name;
		this.formId = formId;
		this.queryFilter = queryFilter;
		this.includeMetadata = includeMetadata;
		this.queryFetchLimit = queryFetchLimit;
		this.cursor = cursor;
	}

	public String getUri() {
		return uri;
	}

	public void setUri(String uri) {
		this.uri = uri;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getFormId() {
		return formId;
	}

	public void setFormId(String formId) {
		this.formId = formId;
	}

	public ITAINNOVAQueryFilterBooleanOperation getQueryFilter() {
		return queryFilter;
	}

	public void setQueryFilter(ITAINNOVAQueryFilterBooleanOperation filters) {
		this.queryFilter = filters;
	}

	public Boolean getIncludeMetadata() {
		return includeMetadata;
	}

	public void setIncludeMetadata(Boolean includeMetadata) {
		this.includeMetadata = includeMetadata;
	}

	public int getQueryFetchLimit() {
		return queryFetchLimit;
	}

	public void setQueryFetchLimit(int queryFetchLimit) {
		this.queryFetchLimit = queryFetchLimit;
	}

	public QueryUIResumePoint getCursor() {
		return cursor;
	}

	public void setCursor(QueryUIResumePoint cursor) {
		this.cursor = cursor;
	}
	
}
