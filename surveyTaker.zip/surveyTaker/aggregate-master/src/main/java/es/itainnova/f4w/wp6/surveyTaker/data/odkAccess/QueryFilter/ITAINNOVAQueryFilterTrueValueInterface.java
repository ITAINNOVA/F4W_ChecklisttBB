package es.itainnova.f4w.wp6.surveyTaker.data.odkAccess.QueryFilter;

import java.util.List;

import es.itainnova.utilities.ITAINNOVAException;

public interface ITAINNOVAQueryFilterTrueValueInterface {
	
	public Boolean evaluateTrueValue() throws ITAINNOVAException;
	public Boolean evaluateTrueValue(Boolean considerUnderlyingClass) throws ITAINNOVAException;
	public List<String> extractArguments();

}
