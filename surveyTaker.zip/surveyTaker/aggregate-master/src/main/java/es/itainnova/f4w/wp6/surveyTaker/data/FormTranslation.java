package es.itainnova.f4w.wp6.surveyTaker.data;

import java.util.ArrayList;
import java.util.List;

public class FormTranslation {
	
	public static String ATTRIBUTE_NAMESPACE="";  
	public static String DEFAULT_ATTRIBUTE_NAME="default";  
	public static String LANGUAGE_ATTRIBUTE_NAME="lang";
	public static String DEFAULT_ATTIBUTE_VALUE="true()";

	
	List<FormElementAttribute> attributes;
	List<FormTranslationText> translation;

	public FormTranslation() {
		// TODO Auto-generated constructor stub
	}

	public FormTranslation(List<FormElementAttribute> attributes, List<FormTranslationText> translation) {
		super();
		this.attributes = attributes;
		this.translation = translation;
	}

	public List<FormElementAttribute> getAttributes() {
		return attributes;
	}

	public void setAttributes(List<FormElementAttribute> attributes) {
		this.attributes = attributes;
	}

	public List<FormTranslationText> getTranslation() {
		return translation;
	}

	public void setTranslation(List<FormTranslationText> translation) {
		this.translation = translation;
	}
	
	public void addText(FormTranslationText formTranslationText)
	{
		if (this.translation==null)
		{
			this.translation = new ArrayList<FormTranslationText>();
		}
		this.translation.add(formTranslationText);
	}

}
