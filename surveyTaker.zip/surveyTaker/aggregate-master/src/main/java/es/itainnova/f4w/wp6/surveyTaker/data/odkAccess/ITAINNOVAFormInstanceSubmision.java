package es.itainnova.f4w.wp6.surveyTaker.data.odkAccess;

import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;

import org.apache.commons.codec.binary.Base64;
import org.opendatakit.aggregate.client.exception.FormNotAvailableException;
import org.opendatakit.aggregate.client.exception.RequestFailureException;
import org.opendatakit.aggregate.client.filter.Filter;
import org.opendatakit.aggregate.client.filter.FilterGroup;
import org.opendatakit.aggregate.client.submission.Column;
import org.opendatakit.aggregate.client.submission.SubmissionUI;
import org.opendatakit.aggregate.client.submission.SubmissionUISummary;
import org.opendatakit.aggregate.constants.ErrorConsts;
import org.opendatakit.aggregate.constants.common.FormElementNamespace;
import org.opendatakit.aggregate.datamodel.FormElementModel;
import org.opendatakit.aggregate.datamodel.TopLevelInstanceData;
import org.opendatakit.aggregate.exception.ODKConversionException;
import org.opendatakit.aggregate.exception.ODKFormNotFoundException;
import org.opendatakit.aggregate.exception.ODKIncompleteSubmissionData;
import org.opendatakit.aggregate.exception.ODKParseException;
import org.opendatakit.aggregate.form.FormFactory;
import org.opendatakit.aggregate.form.IForm;
import org.opendatakit.aggregate.format.element.ElementFormatter;
import org.opendatakit.aggregate.format.element.UiElementFormatter;
import org.opendatakit.aggregate.parser.MultiPartFormData;
import org.opendatakit.aggregate.parser.MultiPartFormItem;
import org.opendatakit.aggregate.parser.SubmissionLockTemplate;
import org.opendatakit.aggregate.query.submission.QueryByUIFilterGroup;
import org.opendatakit.aggregate.query.submission.QueryByUIFilterGroup.CompletionFlag;
import org.opendatakit.aggregate.server.GenerateHeaderInfo;
import org.opendatakit.aggregate.submission.Submission;
import org.opendatakit.aggregate.submission.SubmissionField;
import org.opendatakit.aggregate.submission.SubmissionSet;
import org.opendatakit.aggregate.submission.type.BlobSubmissionType;
import org.opendatakit.aggregate.submission.type.RepeatSubmissionType;
import org.opendatakit.common.datamodel.BinaryContentManipulator;
import org.opendatakit.common.datamodel.DeleteHelper;
import org.opendatakit.common.datamodel.ODKEnumeratedElementException;
import org.opendatakit.common.persistence.CommonFieldsBase;
import org.opendatakit.common.persistence.Datastore;
import org.opendatakit.common.persistence.EntityKey;
import org.opendatakit.common.persistence.client.exception.DatastoreFailureException;
import org.opendatakit.common.persistence.exception.ODKDatastoreException;
import org.opendatakit.common.persistence.exception.ODKEntityNotFoundException;
import org.opendatakit.common.persistence.exception.ODKOverQuotaException;
import org.opendatakit.common.persistence.exception.ODKTaskLockException;
import org.opendatakit.common.security.User;
import org.opendatakit.common.utils.WebUtils;
import org.opendatakit.common.web.CallingContext;
import org.opendatakit.common.web.constants.HtmlConsts;

import es.itainnova.f4w.wp6.surveyTaker.data.FormInstance;
import es.itainnova.f4w.wp6.surveyTaker.data.FormInstanceElement;
import es.itainnova.f4w.wp6.surveyTaker.data.GetFormInstancesListServiceRequest;
import es.itainnova.f4w.wp6.surveyTaker.data.QueryFilterGroup;
import es.itainnova.f4w.wp6.surveyTaker.data.QueryProjection;
import es.itainnova.f4w.wp6.surveyTaker.data.odkAccess.QueryFilter.ITAINNOVAQueryFilterBooleanOperation;
import es.itainnova.utilities.ITAINNOVAException;

public class ITAINNOVAFormInstanceSubmision {

	public static String JPEG = "jpg jpeg";
	public static String GIF = "gif";
	public static String PNG = "png";
	public static String MP3 = "mp3";
	public static String MP4 = "mp4";

	/**
	 * ODK Submission object to be created from the formInstance
	 */
	private Submission submission;
	/**
	 * Track whether this submission was already present and complete.
	 */
	private boolean preExistingComplete = false;

	/**
	 * Data items obtained from a multipart submission
	 */
	private MultiPartFormData submissionFormItems;

	public void submitForm(FormInstance formInstance, boolean isIncomplete, Double openRosaVersion, CallingContext cc,
			HttpServletRequest req) throws ITAINNOVAException {
		String instanceFormVersion;
		String instanceID;
		Long instanceFormVersionL = null;
		String uiVersionString = null;
		Long uiVersionL;
		String submissionDateString;
		Date submissionDate;
		Date markedAsCompleteDate;
		String markedAsCompleteDateString;
		SubmissionLockTemplate modificationLock;
		Map<String, Integer> repeatGroupIndices;
		FormElementModel iFormDataModel;
		Boolean uploadAllBinaries;
		FormInstanceExtension formInstanceExtension;

		String formID;
		IForm iForm;
		/**
		 * The topLevelTableKey representing the form associated data model.
		 */
		EntityKey topLevelTableKey = null;

		formInstanceExtension = new FormInstanceExtension(formInstance);

		formID = formInstanceExtension.getFormID();

		if ((formID == null) || (formID.length() == 0)) {
			throw new ITAINNOVAException("The formID is required for submiting and validating a fulfilled form.");
		}

		try {
			iForm = FormFactory.retrieveFormByFormId(formID, cc);
		} catch (ODKFormNotFoundException e) {
			throw new ITAINNOVAException(e.getMessage());
		} catch (ODKOverQuotaException e) {
			throw new ITAINNOVAException(e.getMessage());
		} catch (ODKDatastoreException e) {
			throw new ITAINNOVAException(e.getMessage());
		}

		if (!iForm.getSubmissionEnabled()) {
			throw new ITAINNOVAException(
					"It's not possible to submit an instance of " + formID + " form because submission is disabled.");
		}

		instanceFormVersion = formInstanceExtension.getVersion();
		if (instanceFormVersion != null && instanceFormVersion.length() > 0) {
			instanceFormVersionL = Long.valueOf(instanceFormVersion);
		}

		uiVersionString = formInstanceExtension.getUiVersion();
		uiVersionL = null;
		if (uiVersionString != null && uiVersionString.length() > 0) {
			uiVersionL = Long.valueOf(uiVersionString);
		}

		instanceID = formInstanceExtension.getInstanceID();
		if (instanceID == null || instanceID.length() == 0) {
			instanceID = CommonFieldsBase.newUri();
			formInstanceExtension.setInstanceID(instanceID);
		}

		submissionDateString = formInstanceExtension.getSubmisionDate();
		if (submissionDateString != null && submissionDateString.length() != 0) {
			submissionDate = WebUtils.parseDate(submissionDateString);
		} else {
			submissionDate = new Date();
		}

		markedAsCompleteDate = new Date();
		markedAsCompleteDateString = formInstanceExtension.getMarkedAsCompletedDate();
		if (markedAsCompleteDateString != null && markedAsCompleteDateString.length() != 0) {
			markedAsCompleteDate = WebUtils.parseDate(markedAsCompleteDateString);
		}

		modificationLock = new SubmissionLockTemplate(formID, instanceID, cc);
		try {
			modificationLock.acquire();
			// retrieve the record with this instanceId from the database or
			// create a new one. This supports submissions having more than
			// 10MB of attachments. In that case, ODK Collect will post the
			// submission in multiple parts and Aggregate needs to be able to
			// merge the parts together. This SHOULD NOT be used to 'update'
			// an existing submission, only to attach additional binary content
			// to an already-uploaded submission.
			boolean preExisting = false;
			try {
				Datastore ds = cc.getDatastore();
				User user = cc.getCurrentUser();
				TopLevelInstanceData fi = (TopLevelInstanceData) ds.getEntity(
						iForm.getTopLevelGroupElement().getFormDataModel().getBackingObjectPrototype(), instanceID,
						user);
				try {
					submission = new Submission(fi, iForm, cc);
				} catch (ODKDatastoreException e) {
					if ((e instanceof ODKEntityNotFoundException) || (e instanceof ODKEnumeratedElementException)) {
						// this is a malformed submission, try to clean this
						// up...
						DeleteHelper.deleteDamagedSubmission(fi, iForm.getAllBackingObjects(), cc);
					}
					if (e instanceof ODKEntityNotFoundException) {
						throw e;
					} else {
						throw new ITAINNOVAException(
								"It's not possible to perform the submision of the given form instance.  SchemaName: "
										+ fi.getTableName() + ".  URI: " + fi.getUri());
					}
				}
				preExisting = true;
				preExistingComplete = submission.isComplete();
			} catch (ODKEntityNotFoundException e) {
				try {
					submission = new Submission(instanceFormVersionL, uiVersionL, instanceID, iForm, submissionDate,
							cc);

				} catch (ODKDatastoreException e1) {
					throw new ITAINNOVAException(
							"It's not possible to perform the submision of the given form instance." + e1.getMessage());
				}
			} catch (ODKOverQuotaException e1) {
				throw new ITAINNOVAException(
						"It's not possible to perform the submision of the given form instance." + e1.getMessage());
			} catch (ODKDatastoreException e1) {
				throw new ITAINNOVAException(
						"It's not possible to perform the submision of the given form instance." + e1.getMessage());
			}

			topLevelTableKey = submission.getKey();

			repeatGroupIndices = new HashMap<String, Integer>();

			iFormDataModel = iForm.getTopLevelGroupElement();
			// if the submission is pre-existing in the datastore, ONLY update
			// binaries
			uploadAllBinaries = submitFormInstance(topLevelTableKey, iForm, iFormDataModel, formInstanceExtension,
					submission, repeatGroupIndices, preExisting, cc);
			submission.setIsComplete(uploadAllBinaries);
			if (uploadAllBinaries) {
				submission.setMarkedAsCompleteDate(markedAsCompleteDate);
			}

			// save the elements inserted into the top-level submission
			try {
				submission.persist(cc);
			} catch (Exception e) {
				List<EntityKey> keys = new ArrayList<EntityKey>();
				try {
					submission.recursivelyAddEntityKeysForDeletion(keys, cc);
				} catch (ODKOverQuotaException e1) {
					throw new ITAINNOVAException(
							"It's not possible to perform the submision of the given form instance." + e1.getMessage());
				} catch (ODKDatastoreException e1) {
					throw new ITAINNOVAException(
							"It's not possible to perform the submision of the given form instance." + e1.getMessage());
				}
				keys.add(submission.getKey());
				try {
					DeleteHelper.deleteEntities(keys, cc);
				} catch (Exception ex) {
					// ignore... we are rolling back...
				}
				throw new ITAINNOVAException("Unable to persist data. " + e.getMessage());
			}
		} catch (ODKTaskLockException e2) {
			throw new ITAINNOVAException(
					"It's not possible to perform the submision of the given form instance." + e2.getMessage());
		} catch (ODKParseException e2) {
			// TODO Auto-generated catch block
			e2.printStackTrace();
		} catch (ODKIncompleteSubmissionData e2) {
			// TODO Auto-generated catch block
			e2.printStackTrace();
		} catch (ODKConversionException e2) {
			// TODO Auto-generated catch block
			e2.printStackTrace();
		} catch (ODKDatastoreException e2) {
			// TODO Auto-generated catch block
			e2.printStackTrace();
		} finally {
			try {
				modificationLock.release();
			} catch (ODKTaskLockException e) {
				throw new ITAINNOVAException(
						"It's not possible to perform the submision of the given form instance." + e.getMessage());
			}
		}
	}

	private Boolean submitFormInstance(EntityKey topLevelTableKey, IForm iForm, FormElementModel node,
			FormInstanceExtension formInstance, SubmissionSet submissionSet, Map<String, Integer> repeatGroupIndicies,
			boolean preExisting, CallingContext cc) throws ODKParseException, ODKIncompleteSubmissionData,
			ODKConversionException, ODKDatastoreException, ITAINNOVAException {
		Boolean submitedForm = false;
		String submissionTag;
		String instanceName = formInstance.getInstanceName();
		List<FormInstanceElement> formInstanceElements;

		if (node == null || instanceName == null) {
			return true;
		}

		// the element name of the fdm is the name of the instance
		submissionTag = node.getElementName();
		if (submissionTag == null) {
			return true;
		}

		// verify that instance name and the fdm node are the same string
		if (!instanceName.equals(submissionTag)) {
			throw new ITAINNOVAException("The instancename: " + instanceName
					+ " does not match the xform data model tag name: " + submissionTag);
		}

		formInstanceElements = formInstance.getElements();
		submitedForm = submitFormInstanceElement(topLevelTableKey, iForm, node, formInstanceElements, submissionSet,
				repeatGroupIndicies, preExisting, cc);

		return submitedForm;

	}

	@SuppressWarnings("unchecked")
	private Boolean submitFormInstanceElement(EntityKey topLevelTableKey, IForm iForm, FormElementModel node,
			List<FormInstanceElement> formInstanceElements, SubmissionSet submissionSet,
			Map<String, Integer> repeatGroupIndicies, boolean preExisting, CallingContext cc) throws ODKParseException,
			ODKIncompleteSubmissionData, ODKConversionException, ODKDatastoreException, ITAINNOVAException {
		Boolean submitted;
		// The element in the model (node) corresponding to the elements of the
		// form instance.
		FormElementModel formElementModel;
		List<FormInstanceElement> groupElements;
		String fullName;
		Integer index;
		SubmissionSet repeatableSubmissionSet;
		long l;
		String value;
		byte[] binaryValue;
		List<FormInstanceElement> binaryFormInstanceElements;
		FormInstanceElement binaryFormInstanceElement;

		// and for each of these, they should be fields under the given node and
		// values within the submissionSet
		submitted = true;
		if (formInstanceElements.size() == 0) {
			return true; // the group is not relevant...
		}
		// and for each of these, they should be fields under the given fdm
		// and values within the submissionSet
		for (FormInstanceElement formInstanceElement : formInstanceElements) {
			formElementModel = node.findElementByName(formInstanceElement.getName());
			if (formElementModel == null) {
				// return submitted;
				continue;
			}
			switch (formElementModel.getElementType()) {
			case METADATA:
				// This keeps lint warnings down
				break;
			case GROUP:
				// need to recurse on these elements keeping the same
				// submissionSet...
				groupElements = (List<FormInstanceElement>) formInstanceElement.getValue();
				submitted = submitted & submitFormInstanceElement(topLevelTableKey, iForm, formElementModel,
						groupElements, submissionSet, repeatGroupIndicies, preExisting, cc);
				break;
			case REPEAT:
				// need to recurse on these elements keeping the same
				// submissionSet...
				groupElements = (List<FormInstanceElement>) formInstanceElement.getValue();
				// get the field that will hold the repeats get the repeat
				// group...
				RepeatSubmissionType repeats = (RepeatSubmissionType) submissionSet.getElementValue(formElementModel);

				// determine the ordinal of the repeat group element we are
				// processing.
				// do this by constructing the submission key for the repeat
				// group and seeing if that key is in the repeatGroupIndicies
				// table. If
				// not, the ordinal is 1L. Otherwise, it is the value in the
				// table plus 1L.
				fullName = repeats.constructSubmissionKey().toString();
				index = repeatGroupIndicies.get(fullName);
				if (index == null) {
					index = 1; // base case -- not yet in repeatGroupIndicies
								// map
				} else {
					++index;
				}
				// save the updated index
				repeatGroupIndicies.put(fullName, index);

				// get or create the instance's submission set for this ordinal
				if (repeats.getNumberRepeats() >= index) {
					// we already have this set defined
					repeatableSubmissionSet = repeats.getSubmissionSets().get(index - 1);
				} else if (repeats.getNumberRepeats() == index - 1) {
					// Create a submission set for a new instance...
					l = repeats.getNumberRepeats() + 1L;
					repeatableSubmissionSet = new SubmissionSet(submissionSet, l, formElementModel, iForm,
							topLevelTableKey, cc);
					repeats.addSubmissionSet(repeatableSubmissionSet);
				} else {
					throw new ITAINNOVAException("incrementing repeats by more than one!");
				}
				// TODO how to deal with this.
				// populate the instance's submission set with values from e...
				submitted = submitted & submitFormInstanceElement(topLevelTableKey, iForm, formElementModel,
						groupElements, repeatableSubmissionSet, repeatGroupIndicies, preExisting, cc);
				break;
			case STRING:
			case JRDATETIME:
			case JRDATE:
			case JRTIME:
			case INTEGER:
			case DECIMAL:
			case BOOLEAN:
			case GEOTRACE:
			case GEOSHAPE:
			case SELECT1: // identifies SelectChoice table
			case SELECTN: // identifies SelectChoice table
				if (!preExisting) {
					value = (String) formInstanceElement.getValue();
					SubmissionField<?> subField = (SubmissionField<?>) submissionSet.getElementValue(formElementModel);
					subField.setValueFromString(value);
				}
				break;
			case GEOPOINT:
				if (!preExisting) {
					value = (String) formInstanceElement.getValue();
					((SubmissionField<?>) submissionSet.getElementValue(node)).setValueFromString(value);
				}
				break;
			case BINARY: // identifies BinaryContent table
			{
				binaryFormInstanceElements = (List<FormInstanceElement>) formInstanceElement.getValue();
				binaryFormInstanceElement = binaryFormInstanceElements.get(0);
				SubmissionField<?> submissionElement = ((SubmissionField<?>) submissionSet
						.getElementValue(formElementModel));
				submitted = submitted & submitFormInstanceElementBinnaryValue(formElementModel, submissionElement,
						binaryFormInstanceElement, iForm, cc);
			}
				break;
			}

			if (!submitted) {
				return submitted;
			}
		}

		return submitted;
	}

	private Boolean submitFormInstanceElementBinnaryValue(FormElementModel node, SubmissionField<?> submissionElement,
			FormInstanceElement binaryData, IForm iForm, CallingContext cc) throws ITAINNOVAException {
		byte[] receivedBytes;
		String value;
		String binaryType;
		String fileName;

		fileName = binaryData.getName();
		binaryType = binaryDataType(fileName);
		value = (String) binaryData.getValue();
		receivedBytes = Base64.decodeBase64(value.getBytes());

		if (value == null)
			return true;

		try {
			submissionElement.setValueFromByteArray(receivedBytes, binaryType, fileName, false, cc);
		} catch (ODKDatastoreException e) {
			throw new ITAINNOVAException(e.getMessage());
		}
		return true;
	}

	private String binaryDataType(String fileName) throws ITAINNOVAException {
		String fileExtension;
		String dataType = null;
		String[] splitedFileName;
		splitedFileName = fileName.split("\\.");

		// TODO review it because it will probably need more file kinds it can
		// also increase the number of avoided files.
		if (splitedFileName.length < 2) {
			throw new ITAINNOVAException("The name of the binnary field (a file name) must include a valid extension.");
		}
		fileExtension = splitedFileName[1].toLowerCase();

		if ((fileExtension == null) || (fileExtension == "")) {
			throw new ITAINNOVAException("The name of the binnary field must include an extension.");
		}

		if (JPEG.contains(fileExtension)) {
			dataType = "image/jpeg";
		}
		if (GIF.contains(fileExtension)) {
			dataType = "image/gif";
		}
		if (PNG.contains(fileExtension)) {
			dataType = "image/png";
		}
		if (MP3.contains(fileExtension)) {
			dataType = "audio/mp3";
		}
		if (MP4.contains(fileExtension)) {
			dataType = "video/mp4";
		}

		return dataType;

	}

	public List<FormInstance> getFormInstancesSubmissionList(
			GetFormInstancesListServiceRequest getFormInstancesListServiceRequest, CallingContext cc) throws ITAINNOVAException {
		List<FormInstance> listFormInstances=null;
		IForm form;
		String formId;
		QueryFilterGroup queryFilterGroup;
		QueryFilterGroupExtension queryFilterGroupExtension;
		
		FilterGroup filterGroup;
		QueryByUIFilterGroup query;
		
		SubmissionUISummary summary;
		GenerateHeaderInfo headerGenerator;

		formId = getFormInstancesListServiceRequest.getFormId();
		formId = getFormInstancesListServiceRequest.getFormId();
		try {
		} catch (Exception e) {
			throw new ITAINNOVAException(e.getMessage());
		}
		try {
			form = FormFactory.retrieveFormByFormId(formId, cc);
			if (!form.hasValidFormDefinition()) {
				throw new ITAINNOVAException(ErrorConsts.FORM_DEFINITION_INVALID);
			}
			queryFilterGroup = getFormInstancesListServiceRequest.getQueryFilterGroup();
			queryFilterGroupExtension = new QueryFilterGroupExtension(queryFilterGroup.getUri(),
					queryFilterGroup.getName(),queryFilterGroup.getFormId(),queryFilterGroup.getQueryFilter(),
					queryFilterGroup.getIncludeMetadata(), queryFilterGroup.getQueryFetchLimit(), queryFilterGroup.getCursor());
			filterGroup =  queryFilterGroupExtension.convertQueryFilterGroupToODKFilterGroup();
			query = new QueryByUIFilterGroup(form, filterGroup,	CompletionFlag.ONLY_COMPLETE_SUBMISSIONS, cc);

			summary = new SubmissionUISummary(form.getViewableName());
			headerGenerator = new GenerateHeaderInfo(filterGroup, summary, form);
			headerGenerator.processForHeaderInfo(form.getTopLevelGroupElement());
			List<FormElementModel> filteredElements = headerGenerator.getIncludedElements();
			ElementFormatter elemFormatter = new UiElementFormatter(cc.getServerURL(),
					headerGenerator.getGeopointIncludes());
			List<FormElementNamespace> includedTypes = headerGenerator.includedFormElementNamespaces();
			query.populateSubmissions(summary, filteredElements, elemFormatter, includedTypes, cc);

			listFormInstances = this.copyValuesToFormInstances(form, summary,
					queryFilterGroup,  getFormInstancesListServiceRequest.getQueryProjection(), cc);

		} catch (ODKFormNotFoundException e) {
			throw new ITAINNOVAException(e.getMessage());
		} catch (ODKOverQuotaException e) {
			throw new ITAINNOVAException(e.getMessage());
		} catch (ODKDatastoreException e) {
			throw new ITAINNOVAException(e.getMessage());
		}

		return listFormInstances;
	}
	
	private List<FormInstance> copyValuesToFormInstances(IForm form, SubmissionUISummary summary, 
			 QueryFilterGroup queryFilterGroup,  QueryProjection queryProjection, CallingContext cc) throws ITAINNOVAException
	{
		List<FormInstance> listFormInstances=null;
		List<SubmissionUI> listSubmissionUIs;
		List<Column> listColumns;
		SubmissionUI submissionUI;
		Integer index;
		Integer addedSubmissions;
		Integer requiredSubmissions;
		FormInstanceExtension formInstanceExtension;
		FormInstance formInstance;
		Boolean addInstanceMetadata;
		ITAINNOVAQueryFilterBooleanOperation queryFilter;
		
		if ((form!=null) && (summary!=null))
		{
			listFormInstances = new ArrayList<FormInstance>();
			listColumns = summary.getHeaders();
			listSubmissionUIs = summary.getSubmissions();
			addInstanceMetadata = queryFilterGroup.getIncludeMetadata();
			addedSubmissions =0;
			requiredSubmissions = queryFilterGroup.getQueryFetchLimit();
			queryFilter = queryFilterGroup.getQueryFilter();

			for (index=0; (index< listSubmissionUIs.size()) && (addedSubmissions<requiredSubmissions); index++)
			{
				submissionUI = listSubmissionUIs.get(index);
				
				if (addSubMission(listColumns, submissionUI, queryFilter))
				{
					addedSubmissions++;
					formInstanceExtension = new FormInstanceExtension(form, submissionUI, listColumns, queryProjection,
							addInstanceMetadata, cc);
					formInstance = new FormInstance(formInstanceExtension.getElements(),
							formInstanceExtension.getAttributes());
					listFormInstances.add(formInstance);
				}
			}
		}
		return listFormInstances;
	}
	
	private Boolean addSubMission(List<Column> listColumns, SubmissionUI submissionUI, ITAINNOVAQueryFilterBooleanOperation queryFilter) throws ITAINNOVAException
	{
		Boolean addSubmission=false;
		HashMap<String, String> keyValues;
		ITAINNOVAQueryFilterBooleanOperation replacedVariablesOperation;
		List<String> arguments;
		

		keyValues = this.createColumnsValuesHashMap(listColumns, submissionUI);
		replacedVariablesOperation = queryFilter.createFilterReplacingColumnNamesByValues(keyValues);
		
		if (replacedVariablesOperation!=null)
		{
			addSubmission = replacedVariablesOperation.evaluateTrueValue();
		}
		return addSubmission;
	}
	
	private HashMap<String, String> createColumnsValuesHashMap(List<Column> listColumns, SubmissionUI submissionUI)
	{
		HashMap<String, String> hashMap=null;
		Integer index;
		String key;
		String value;
		
		if ((listColumns!=null) && (submissionUI !=null) && (submissionUI.getValues()!=null))
		{
			hashMap = new HashMap<String, String>();
			for (index=0; index < listColumns.size(); index++)
			{
				key = listColumns.get(index).getDisplayHeader();
				value = submissionUI.getValues().get(index);
				hashMap.put(key, value);
			}
		}
		return hashMap;
	}
	
}
