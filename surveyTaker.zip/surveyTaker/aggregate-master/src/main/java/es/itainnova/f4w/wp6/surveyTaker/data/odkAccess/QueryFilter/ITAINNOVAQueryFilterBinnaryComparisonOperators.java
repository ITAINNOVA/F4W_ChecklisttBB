package es.itainnova.f4w.wp6.surveyTaker.data.odkAccess.QueryFilter;

public enum ITAINNOVAQueryFilterBinnaryComparisonOperators {
	EQUAL ("EQUAL"),
	DISTINTC("DISTINCT"),
	GREATER("GREATER"),
	SMALLER("SMALLER"),
	GREATEROREQUAL("GREATEROREQUAL"),
	SMALLEROREQUAL("SMALLEROREQUAL"),
	CONTAINS("CONTAINS");
	
	private String stringRepresentation;
	
	ITAINNOVAQueryFilterBinnaryComparisonOperators()
	{
		
	}
	ITAINNOVAQueryFilterBinnaryComparisonOperators(String stringRepresentation)
	{
		this.stringRepresentation = stringRepresentation;
	}

	public String getStringRepresentation() {
		return stringRepresentation;
	}

	public void setStringRepresentation(String stringRepresentation) {
		this.stringRepresentation = stringRepresentation;
	}
	
	public static ITAINNOVAQueryFilterBinnaryComparisonOperators giveMeBinnaryComparisonOperatorFromJSONrepresentation
		(String jsonRepresentation)
	{
		ITAINNOVAQueryFilterBinnaryComparisonOperators operator=null;
		
		if (jsonRepresentation.equals(ITAINNOVAQueryFilterBinnaryComparisonOperators.EQUAL.stringRepresentation))
		{
			operator = ITAINNOVAQueryFilterBinnaryComparisonOperators.EQUAL;
		}
		if (jsonRepresentation.equals(ITAINNOVAQueryFilterBinnaryComparisonOperators.DISTINTC.stringRepresentation))
		{
			operator = ITAINNOVAQueryFilterBinnaryComparisonOperators.DISTINTC;
		}
		if (jsonRepresentation.equals(ITAINNOVAQueryFilterBinnaryComparisonOperators.GREATER.stringRepresentation))
		{
			operator = ITAINNOVAQueryFilterBinnaryComparisonOperators.GREATER;
		}
		if (jsonRepresentation.equals(ITAINNOVAQueryFilterBinnaryComparisonOperators.SMALLER.stringRepresentation))
		{
			operator = ITAINNOVAQueryFilterBinnaryComparisonOperators.SMALLER;
		}
		if (jsonRepresentation.equals(ITAINNOVAQueryFilterBinnaryComparisonOperators.GREATEROREQUAL.stringRepresentation))
		{
			operator = ITAINNOVAQueryFilterBinnaryComparisonOperators.GREATEROREQUAL;
		}
		if (jsonRepresentation.equals(ITAINNOVAQueryFilterBinnaryComparisonOperators.SMALLEROREQUAL.stringRepresentation))
		{
			operator = ITAINNOVAQueryFilterBinnaryComparisonOperators.SMALLEROREQUAL;
		}
		if (jsonRepresentation.equals(ITAINNOVAQueryFilterBinnaryComparisonOperators.CONTAINS.stringRepresentation))
		{
			operator = ITAINNOVAQueryFilterBinnaryComparisonOperators.CONTAINS;
		}
		
		return operator;
	}

}
