package es.itainnova.f4w.wp6.surveyTaker.data.odkAccess;

import java.io.UnsupportedEncodingException;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import org.opendatakit.aggregate.client.submission.Column;
import org.opendatakit.aggregate.client.submission.SubmissionUI;
import org.opendatakit.aggregate.datamodel.FormElementModel;
import org.opendatakit.aggregate.exception.ODKFormNotFoundException;
import org.opendatakit.aggregate.form.IForm;
import org.opendatakit.aggregate.form.PersistentResults;
import org.opendatakit.aggregate.submission.Submission;
import org.opendatakit.aggregate.submission.SubmissionElement;
import org.opendatakit.aggregate.submission.SubmissionKey;
import org.opendatakit.aggregate.submission.SubmissionKeyPart;
import org.opendatakit.aggregate.submission.type.BlobSubmissionType;
import org.opendatakit.common.persistence.exception.ODKDatastoreException;
import org.opendatakit.common.persistence.exception.ODKOverQuotaException;
import org.opendatakit.common.web.CallingContext;

import es.itainnova.f4w.wp6.surveyTaker.data.FormInstanceElement;
import es.itainnova.utilities.ITAINNOVAException;

public class FormInstanceBinnary {
	
	private static String BINARY_URI_SEPARATOR="blobKey=";
	public static String  UNROOTEDFILENAME_ELEMENT_NAME="unrootedFileName";
	public static String  BLOB_ELEMENT_NAME="blob";
	public static String  CONTENTTYPE_ELEMENT_NAME="contentType";
	public static String  CONTENTLENGTH_ELEMENT_NAME="contentLength";
	
	private String valueURI;
	private String name;
	private String formID;
	private CallingContext cc;
	
	
	
	public FormInstanceBinnary() {
		super();
	}

	public FormInstanceBinnary(String valueURI, String name, String formID, CallingContext cc) {
		super();
		this.valueURI = valueURI;
		this.name = name;
		this.formID = formID;
		this.cc = cc;
	}

	public String getValueURI() {
		return valueURI;
	}

	public void setValueURI(String valueURI) {
		this.valueURI = valueURI;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getFormID() {
		return formID;
	}

	public void setFormID(String formID) {
		this.formID = formID;
	}

	public CallingContext getCc() {
		return cc;
	}

	public void setCc(CallingContext cc) {
		this.cc = cc;
	}

	public List<FormInstanceElement> getBlob(String valueURI, String name, String formID, CallingContext cc) 
			throws ITAINNOVAException
	{
		List<FormInstanceElement> fomFormInstanceElements=null;
		FormInstanceElement formInstanceElement=null;
		byte[] blobValue;
		
		String decodedValueURI;
		String keyString;
		String previewSizeString;
        String lastUpdateDate;
        String contentType=null;
        String contentLength=null;
		SubmissionKey submissionKey;
		String unrootedFileName=null;
		List<SubmissionKeyPart> parts;
		Submission submission;
		BlobSubmissionType blobSubmissionType;
		SubmissionElement submissionElement;
		
		try {
			decodedValueURI = java.net.URLDecoder.decode(valueURI, "UTF-8");
		} catch (UnsupportedEncodingException e) {
			throw new ITAINNOVAException(e.getMessage());
		}
		blobValue = null;
	    // verify parameters are present
	    keyString = getBlobInternalURI(decodedValueURI);
	    //previewSizeString = null;
	    
	    submissionKey = new SubmissionKey(keyString);
	    parts = submissionKey.splitSubmissionKey();
	    if (parts.get(0).getElementName().equals(PersistentResults.FORM_ID_PERSISTENT_RESULT)) {
	      // special handling for persistent results data...
/*	      try {
	        PersistentResults p = new PersistentResults(key, cc);
	        ResultFileInfo info = p.getResultFileInfo(cc);
	        if (info == null) {
	          resp.sendError(HttpServletResponse.SC_INTERNAL_SERVER_ERROR,
	              "Unable to retrieve attachment");
	          return;
	        }
	        unrootedFileName = info.unrootedFilename;
	        contentType = info.contentType;
	        contentLength = info.contentLength;
	        imageBlob = p.getResultFileContents(cc);
	        lastUpdateDate = p.getCompletionDate();
	      } catch (ODKOverQuotaException e) {
	        e.printStackTrace();
	        quotaExceededError(resp);
	        return;
	      } catch (ODKDatastoreException e) {
	        e.printStackTrace();
	        resp.sendError(HttpServletResponse.SC_INTERNAL_SERVER_ERROR,
	            "Unable to retrieve attachment");
	        return;
	      }*/

	    } 
	    else 
	    {
	      try {
	        submission = Submission.fetchSubmission(parts, cc);
	      } catch (ODKFormNotFoundException e1) {
	    	  throw new ITAINNOVAException(e1.getMessage());
	      } catch (ODKOverQuotaException e) {
	    	  throw new ITAINNOVAException(e.getMessage());
	      } catch (ODKDatastoreException e) {
	    	  throw new ITAINNOVAException(e.getMessage());
	      }

	      if (submission != null) 
	      {
	        try 
	        {
	        	submissionElement = submission.resolveSubmissionKey(parts);
	        	if (submissionElement instanceof BlobSubmissionType) 
	        	{
	        		blobSubmissionType = (BlobSubmissionType) submissionElement;
	        	}
	        	else 
	        	{
	        		throw new ITAINNOVAException("Requested object is not a binary one.");
	        	}
	        } 
	        catch (Exception e) 
	        {
	        	throw new ITAINNOVAException(e.getMessage());
	        }

	        try {
	          // ordinal should be 1 if there is just 1 attachment...
	          int ordinal = blobSubmissionType.getAttachmentCount(cc);
	          if ( ordinal != 1 ) {
	            // we have multiple attachments
	            // -- use submissionKey to determine which one we want
	            SubmissionKeyPart p = parts.get(parts.size() - 1);
	            Long ord = p.getOrdinalNumber();
	            if (ord == null) {
	              throw new ITAINNOVAException("Attachment request must be fully qualified.");
	            }
	            // OK. This is the attachment we want...
	            ordinal = ord.intValue();
	          }
	          blobValue = blobSubmissionType.getBlob(ordinal, cc);
	          unrootedFileName = blobSubmissionType.getUnrootedFilename(ordinal, cc);
	          lastUpdateDate = blobSubmissionType.getLastUpdateDate(ordinal, cc).toLocaleString();
	          unrootedFileName = blobSubmissionType.getUnrootedFilename(ordinal, cc);
	          contentType = blobSubmissionType.getContentType(ordinal, cc);
	          contentLength = blobSubmissionType.getContentLength(ordinal, cc).toString();
	        } catch (ODKOverQuotaException e) {
	        	throw new ITAINNOVAException(e.getMessage());
	        } catch (ODKDatastoreException e) {
	        	throw new ITAINNOVAException(e.getMessage());
	        }
	      }
	    }

	    if (blobValue != null && blobValue.length > 0) 
	    {
	    	if ((unrootedFileName!=null) && (unrootedFileName.length()==0))
	    	{
	    		throw new ITAINNOVAException("The name for the binnary content file is not provided for URI:"+decodedValueURI);
	    	}
	    	formInstanceElement = new FormInstanceElement(UNROOTEDFILENAME_ELEMENT_NAME, unrootedFileName);

	    	fomFormInstanceElements = new ArrayList<FormInstanceElement>();
	    	fomFormInstanceElements.add(formInstanceElement);

	    	formInstanceElement = new FormInstanceElement(BLOB_ELEMENT_NAME, blobValue);
	    	fomFormInstanceElements.add(formInstanceElement);

	    	formInstanceElement = new FormInstanceElement(CONTENTTYPE_ELEMENT_NAME, contentType);
	    	fomFormInstanceElements.add(formInstanceElement);

	    	formInstanceElement = new FormInstanceElement(CONTENTLENGTH_ELEMENT_NAME, contentLength);
	    	fomFormInstanceElements.add(formInstanceElement);

	    } else 
	    {
	    	throw new ITAINNOVAException("Binnary content does not exist or is not accesible usin the provided URI:"+decodedValueURI);
	    }

	    
		return fomFormInstanceElements;
	}
	
	private String getBlobInternalURI(String sevletURI) throws ITAINNOVAException
	{
		String[] splittedString;
		String splittedURI=null;
		
		if (sevletURI.contains(BINARY_URI_SEPARATOR))
		{
			splittedString = sevletURI.split(BINARY_URI_SEPARATOR);
			if (splittedString.length<2)
			{
				throw new ITAINNOVAException("A non valid value was received in the URI of the binary field:" + sevletURI);
			}
			splittedURI = splittedString[1];
		}
		else
		{
			splittedURI =sevletURI;
		}
		
		return splittedURI;
	}


}
