package es.itainnova.f4w.wp6.surveyTaker.data;

import java.util.ArrayList;
import java.util.List;

public class FormList {

	List<Form> forms;

	public FormList() {
	}

	public FormList(List<Form> forms) {
		super();
		this.forms = forms;
	}

	public List<Form> getForms() {
		return forms;
	}

	public void setForms(List<Form> forms) {
		this.forms = forms;
	}
	
	public void addForm(Form form)
	{
		if (this.forms==null)
		{
			forms = new ArrayList<Form>();
		}
		if (form!=null)
		{
			forms.add(form);
		}
	}
	
}
