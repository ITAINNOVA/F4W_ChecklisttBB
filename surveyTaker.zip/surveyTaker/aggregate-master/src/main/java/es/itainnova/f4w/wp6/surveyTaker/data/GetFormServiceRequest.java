package es.itainnova.f4w.wp6.surveyTaker.data;

public class GetFormServiceRequest extends ServiceRequest {
	
	String formID;
	Boolean verbose;
	Boolean readable;
	
	public GetFormServiceRequest() {
		super();
	}
	public GetFormServiceRequest(String formID, Boolean verbose, Boolean readable) {
		super();
		this.formID = formID;
		this.verbose = verbose;
		this.readable = readable;
	}
	public String getFormID() {
		return formID;
	}
	public void setFormID(String formID) {
		this.formID = formID;
	}
	public Boolean getVerbose() {
		return verbose;
	}
	public void setVerbose(Boolean verbose) {
		this.verbose = verbose;
	}
	public Boolean getReadable() {
		return readable;
	}
	public void setReadable(Boolean readable) {
		this.readable = readable;
	}
	

}
