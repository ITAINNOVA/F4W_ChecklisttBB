package es.itainnova.f4w.wp6.surveyTaker.data;

public class ListFormsServiceRequest extends ServiceRequest {
	
	String formID;
	Boolean verbose;

	public ListFormsServiceRequest() {
	}
	public ListFormsServiceRequest(String userToken, String formID, Boolean verbose) {
		super(userToken);
		this.formID = formID;
		this.verbose = verbose;
	}
	public String getFormID() {
		return formID;
	}
	public void setFormID(String formID) {
		this.formID = formID;
	}
	public Boolean getVerbose() {
		return verbose;
	}
	public void setVerbose(Boolean verbose) {
		this.verbose = verbose;
	}
	

}