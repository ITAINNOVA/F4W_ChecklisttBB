#!/bin/bash
# Run updater jar
java -jar ./ODKAggregateAppEngineUpdater.jar
exit $?
